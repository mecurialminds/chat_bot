$(function () {
    var countriesCode = {
        "Andorra": {
            "CountryID": "AD"
        },
        "United Arab Emirates": {
            "CountryID": "AE"
        },
        "Afghanistan": {
            "CountryID": "AF"
        },
        "Argentina": {
            "CountryID": "AR"
        },
        "Anguilla": {
            "CountryID": "AI"
        },
        "Albania": {
            "CountryID": "AL"
        },
        "Aruba": {
            "CountryID": "AW"
        },
        "Netherlands Antilles": {
            "CountryID": "AN"
        },
        "Angola": {
            "CountryID": "AO"
        },
        "Antarctica": {
            "CountryID": "AQ"
        },
        "Armenia": {
            "CountryID": "AM"
        },
        "American Samoa": {
            "CountryID": "AS"
        },
        "Austria": {
            "CountryID": "AT"
        },
        "Australia": {
            "CountryID": "AU"
        },
        "Azerbaijan": {
            "CountryID": "AZ"
        },
        "Bosnia And Herzegovina": {
            "CountryID": "BA"
        },
        "Barbados": {
            "CountryID": "BB"
        },
        "Bangladesh": {
            "CountryID": "BD"
        },
        "Belgium": {
            "CountryID": "BE"
        },
        "Burkina Faso": {
            "CountryID": "BF"
        },
        "Bulgaria": {
            "CountryID": "BG"
        },
        "Bahrain": {
            "CountryID": "BH"
        },
        "Burundi": {
            "CountryID": "BI"
        },
        "Benin": {
            "CountryID": "BJ"
        },
        "Saint Barthelemy": {
            "CountryID": "BL"
        },
        "Bermuda": {
            "CountryID": "BM"
        },
        "Brunei Darussalam": {
            "CountryID": "BN"
        },
        "Bolivia": {
            "CountryID": "BO"
        },
        "Brazil": {
            "CountryID": "BR"
        },
        "Bahamas": {
            "CountryID": "BS"
        },
        "Bhutan": {
            "CountryID": "BT"
        },
        "Botswana": {
            "CountryID": "BW"
        },
        "Belarus": {
            "CountryID": "BY"
        },
        "Belize": {
            "CountryID": "BZ"
        },
        "Canada": {
            "CountryID": "CA"
        },
        "Cocos Islands": {
            "CountryID": "CC"
        },
        "Democratic Republic of Congo": {
            "CountryID": "CD"
        },
        "Central African Republic": {
            "CountryID": "CF"
        },
        "Congo": {
            "CountryID": "CG"
        },
        "Switzerland": {
            "CountryID": "CH"
        },
        "Cook Islands": {
            "CountryID": "CK"
        },
        "Chile": {
            "CountryID": "CL"
        },
        "Cambodia": {
            "CountryID": "KH"
        },
        "Cameroon": {
            "CountryID": "CM"
        },
        "China": {
            "CountryID": "CN"
        },
        "Colombia": {
            "CountryID": "CO"
        },
        "Costa Rica": {
            "CountryID": "CR"
        },
        "Cuba": {
            "CountryID": "CU"
        },
        "Cape Verde": {
            "CountryID": "CV"
        },
        "Christmas Island": {
            "CountryID": "CX"
        },
        "Cyprus": {
            "CountryID": "CY"
        },
        "Czech Republic": {
            "CountryID": "CZ"
        },
        "Germany": {
            "CountryID": "DE"
        },
        "Diego Garcia": {
            "CountryID": "DG"
        },
        "Djibouti": {
            "CountryID": "DJ"
        },
        "Denmark": {
            "CountryID": "DK"
        },
        "Dominica": {
            "CountryID": "DM"
        },
        "Dominican Republic": {
            "CountryID": "DO"
        },
        "Algeria": {
            "CountryID": "DZ"
        },
        "Ecuador": {
            "CountryID": "EC"
        },
        "Estonia": {
            "CountryID": "EE"
        },
        "Egypt": {
            "CountryID": "EG"
        },
        "Eritrea": {
            "CountryID": "ER"
        },
        "Spain": {
            "CountryID": "ES"
        },
        "Ethiopia": {
            "CountryID": "ET"
        },
        "Finland": {
            "CountryID": "FI"
        },
        "Fiji": {
            "CountryID": "FJ"
        },
        "Falkland Islands Malvinas": {
            "CountryID": "FK"
        },
        "Micronesia": {
            "CountryID": "FM"
        },
        "Faroe Islands": {
            "CountryID": "FO"
        },
        "France": {
            "CountryID": "FR"
        },
        "Gabon": {
            "CountryID": "GA"
        },
        "United Kingdom": {
            "CountryID": "GB"
        },
        "Guadeloupe": {
            "CountryID": "GP"
        },
        "Georgia": {
            "CountryID": "GE"
        },
        "French Guiana": {
            "CountryID": "GF"
        },
        "Gibraltar": {
            "CountryID": "GI"
        },
        "Greece": {
            "CountryID": "GR"
        },
        "Grenada": {
            "CountryID": "GD"
        },
        "Gambia": {
            "CountryID": "GM"
        },
        "Guam": {
            "CountryID": "GU"
        },
        "Equatorial Guinea": {
            "CountryID": "GQ"
        },
        "Greenland": {
            "CountryID": "GL"
        },
        "Guinea": {
            "CountryID": "GN"
        },
        "Guatemala": {
            "CountryID": "GT"
        },
        "Guinea-Bissau": {
            "CountryID": "GW"
        },
        "Guyana": {
            "CountryID": "GY"
        },
        "Hong Kong": {
            "CountryID": "HK"
        },
        "Honduras": {
            "CountryID": "HN"
        },
        "Croatia": {
            "CountryID": "HR"
        },
        "Haiti": {
            "CountryID": "HT"
        },
        "Hungary": {
            "CountryID": "HU"
        },
        "Indonesia": {
            "CountryID": "ID"
        },
        "Ireland": {
            "CountryID": "IE"
        },
        "India": {
            "CountryID": "IN"
        },
        "Iraq": {
            "CountryID": "IQ"
        },
        "Iran": {
            "CountryID": "IR"
        },
        "Iceland": {
            "CountryID": "IS"
        },
        "Italy": {
            "CountryID": "IT"
        },
        "Japan": {
            "CountryID": "JP"
        },
        "Ivory Coast": {
            "CountryID": "CI"
        },
        "Jordan": {
            "CountryID": "JO"
        },
        "Jamaica": {
            "CountryID": "JM"
        },
        "Kenya": {
            "CountryID": "KE"
        },
        "Kyrgyzstan": {
            "CountryID": "KG"
        },
        "Kiribati": {
            "CountryID": "KI"
        },
        "Comoros": {
            "CountryID": "KM"
        },
        "Saint Kitts And Nevis": {
            "CountryID": "KN"
        },
        "Korea North": {
            "CountryID": "KP"
        },
        "Korea South": {
            "CountryID": "KR"
        },
        "Kuwait": {
            "CountryID": "KW"
        },
        "Cayman Islands": {
            "CountryID": "KY"
        },
        "Kazakhstan": {
            "CountryID": "KZ"
        },
        "Laos": {
            "CountryID": "LA"
        },
        "Lebanon": {
            "CountryID": "LB"
        },
        "Saint Lucia": {
            "CountryID": "LC"
        },
        "Liechtenstein": {
            "CountryID": "LI"
        },
        "Sri Lanka": {
            "CountryID": "LK"
        },
        "Liberia": {
            "CountryID": "LR"
        },
        "Lesotho": {
            "CountryID": "LS"
        },
        "Lithuania": {
            "CountryID": "LT"
        },
        "Luxembourg": {
            "CountryID": "LU"
        },
        "Latvia": {
            "CountryID": "LV"
        },
        "Libya": {
            "CountryID": "LY"
        },
        "Morocco": {
            "CountryID": "MA"
        },
        "Monaco": {
            "CountryID": "MC"
        },
        "Moldova": {
            "CountryID": "MD"
        },
        "Montenegro": {
            "CountryID": "ME"
        },
        "Saint Martin": {
            "CountryID": "MF"
        },
        "Madagascar": {
            "CountryID": "MG"
        },
        "Marshall Islands": {
            "CountryID": "MH"
        },
        "Macedonia": {
            "CountryID": "MK"
        },
        "Mali": {
            "CountryID": "ML"
        },
        "Myanmar": {
            "CountryID": "MM"
        },
        "Mongolia": {
            "CountryID": "MN"
        },
        "Macao, China": {
            "CountryID": "MO"
        },
        "Northern Mariana Islands": {
            "CountryID": "MP"
        },
        "Martinique": {
            "CountryID": "MQ"
        },
        "Mauritania": {
            "CountryID": "MR"
        },
        "Montserrat": {
            "CountryID": "MS"
        },
        "Malta": {
            "CountryID": "MT"
        },
        "Mauritius": {
            "CountryID": "MU"
        },
        "Maldives": {
            "CountryID": "MV"
        },
        "Malawi": {
            "CountryID": "MW"
        },
        "Mexico": {
            "CountryID": "MX"
        },
        "Malaysia": {
            "CountryID": "MY"
        },
        "Mozambique": {
            "CountryID": "MZ"
        },
        "Namibia": {
            "CountryID": "NA"
        },
        "New Caledonia": {
            "CountryID": "NC"
        },
        "Niger": {
            "CountryID": "NE"
        },
        "Norfolk Island": {
            "CountryID": "NF"
        },
        "Nigeria": {
            "CountryID": "NG"
        },
        "Nicaragua": {
            "CountryID": "NI"
        },
        "Netherlands": {
            "CountryID": "NL"
        },
        "Norway": {
            "CountryID": "NO"
        },
        "Nepal": {
            "CountryID": "NP"
        },
        "Nauru": {
            "CountryID": "NR"
        },
        "Niue": {
            "CountryID": "NU"
        },
        "New Zealand": {
            "CountryID": "NZ"
        },
        "Oman": {
            "CountryID": "OM"
        },
        "Panama": {
            "CountryID": "PA"
        },
        "Peru": {
            "CountryID": "PE"
        },
        "French Polynesia\/Tahiti": {
            "CountryID": "PF"
        },
        "Papua New Guinea": {
            "CountryID": "PG"
        },
        "Philippines": {
            "CountryID": "PH"
        },
        "Pakistan": {
            "CountryID": "PK"
        },
        "Poland": {
            "CountryID": "PL"
        },
        "Saint Pierre And Miquelon": {
            "CountryID": "PM"
        },
        "Puerto Rico": {
            "CountryID": "PR"
        },
        "Palestine": {
            "CountryID": "PS"
        },
        "Portugal": {
            "CountryID": "PT"
        },
        "Palau": {
            "CountryID": "PW"
        },
        "Paraguay": {
            "CountryID": "PY"
        },
        "Reunion": {
            "CountryID": "RE"
        },
        "Romania": {
            "CountryID": "RO"
        },
        "Serbia": {
            "CountryID": "RS"
        },
        "Russia": {
            "CountryID": "RU"
        },
        "Rwanda": {
            "CountryID": "RW"
        },
        "Saudi Arabia": {
            "CountryID": "SA"
        },
        "Solomon Islands": {
            "CountryID": "SB"
        },
        "Seychelles": {
            "CountryID": "SC"
        },
        "Sudan": {
            "CountryID": "SD"
        },
        "Sweden": {
            "CountryID": "SE"
        },
        "Singapore": {
            "CountryID": "SG"
        },
        "Saint Helena": {
            "CountryID": "SH"
        },
        "Slovenia": {
            "CountryID": "SI"
        },
        "Slovakia": {
            "CountryID": "SK"
        },
        "Sierra Leone": {
            "CountryID": "SL"
        },
        "San Marino": {
            "CountryID": "SM"
        },
        "Senegal": {
            "CountryID": "SN"
        },
        "Somalia": {
            "CountryID": "SO"
        },
        "Suriname": {
            "CountryID": "SR"
        },
        "South Sudan": {
            "CountryID": "SS"
        },
        "Sao Tome And Principe": {
            "CountryID": "ST"
        },
        "El Salvador": {
            "CountryID": "SV"
        },
        "Syria": {
            "CountryID": "SY"
        },
        "Swaziland": {
            "CountryID": "SZ"
        },
        "Turks And Caicos Islands": {
            "CountryID": "TC"
        },
        "Chad": {
            "CountryID": "TD"
        },
        "Togo": {
            "CountryID": "TG"
        },
        "Thailand": {
            "CountryID": "TH"
        },
        "Tajikistan": {
            "CountryID": "TJ"
        },
        "Tokelau": {
            "CountryID": "TK"
        },
        "East Timor": {
            "CountryID": "TL"
        },
        "Turkmenistan": {
            "CountryID": "TM"
        },
        "Tunisia": {
            "CountryID": "TN"
        },
        "Tonga": {
            "CountryID": "TO"
        },
        "Turkey": {
            "CountryID": "TR"
        },
        "Trinidad And Tobago": {
            "CountryID": "TT"
        },
        "Tuvalu": {
            "CountryID": "TV"
        },
        "Taiwan, China": {
            "CountryID": "TW"
        },
        "Tanzania": {
            "CountryID": "TZ"
        },
        "Ukraine": {
            "CountryID": "UA"
        },
        "Uganda": {
            "CountryID": "UG"
        },
        "United States Of America": {
            "CountryID": "US"
        },
        "Uruguay": {
            "CountryID": "UY"
        },
        "Uzbekistan": {
            "CountryID": "UZ"
        },
        "Vatican": {
            "CountryID": "VA"
        },
        "Saint Vincent And The Grenadines": {
            "CountryID": "VC"
        },
        "Venezuela": {
            "CountryID": "VE"
        },
        "British Virgin Islands": {
            "CountryID": "VG"
        },
        "United States Virgin Islands": {
            "CountryID": "VI"
        },
        "Vietnam": {
            "CountryID": "VN"
        },
        "Vanuatu": {
            "CountryID": "VU"
        },
        "Wallis And Futuna": {
            "CountryID": "WF"
        },
        "Western Samoa \/ Samoa Country": {
            "CountryID": "WS"
        },
        "Yemen": {
            "CountryID": "YE"
        },
        "Mayotte": {
            "CountryID": "YT"
        },
        "South Africa": {
            "CountryID": "ZA"
        },
        "Zambia": {
            "CountryID": "ZM"
        },
        "Zimbabwe": {
            "CountryID": "ZW"
        },
        "Antigua And Barbuda": {
            "CountryID": "AG"
        },
        "Ghana": {
            "CountryID": "GH"
        }
    };

    var countriesByCode = {
        "AF": {
            "Country": "Afghanistan",
            "CountryCode": "+93",
            "rate": "0.99",
            "applicable": ""
        },
        "AL": {
            "Country": "Albania",
            "CountryCode": "+355",
            "rate": "0.99",
            "applicable": ""
        },
        "DZ": {
            "Country": "Algeria",
            "CountryCode": "+213",
            "rate": "1.5",
            "applicable": ""
        },
        "AS": {
            "Country": "American Samoa",
            "CountryCode": "+684",
            "rate": "1.66",
            "applicable": ""
        },
        "AD": {
            "Country": "Andorra",
            "CountryCode": "+376",
            "rate": "0.99",
            "applicable": ""
        },
        "AO": {
            "Country": "Angola",
            "CountryCode": "+244",
            "rate": "0.99",
            "applicable": ""
        },
        "AI": {
            "Country": "Anguilla",
            "CountryCode": "+1264",
            "rate": "0.99",
            "applicable": ""
        },
        "AQ": {
            "Country": "Antarctica",
            "CountryCode": "+672",
            "rate": "2.8",
            "applicable": ""
        },
        "AG": {
            "Country": "Antigua And Barbuda",
            "CountryCode": "+1268",
            "rate": "0.99",
            "applicable": ""
        },
        "AR": {
            "Country": "Argentina",
            "CountryCode": "+54",
            "rate": "0.99",
            "applicable": ""
        },
        "AM": {
            "Country": "Armenia",
            "CountryCode": "+374",
            "rate": "0.99",
            "applicable": ""
        },
        "AW": {
            "Country": "Aruba",
            "CountryCode": "+297",
            "rate": "0.99",
            "applicable": ""
        },
        "AU": {
            "Country": "Australia",
            "CountryCode": "+61",
            "rate": "0.99",
            "applicable": ""
        },
        "AT": {
            "Country": "Austria",
            "CountryCode": "+43",
            "rate": "0.99",
            "applicable": ""
        },
        "AZ": {
            "Country": "Azerbaijan",
            "CountryCode": "+994",
            "rate": "1.66",
            "applicable": ""
        },
        "BS": {
            "Country": "Bahamas",
            "CountryCode": "+1242",
            "rate": "1.5",
            "applicable": ""
        },
        "BH": {
            "Country": "Bahrain",
            "CountryCode": "+973",
            "rate": "0.99",
            "applicable": "0.45"
        },
        "BD": {
            "Country": "Bangladesh",
            "CountryCode": "+880",
            "rate": "0.99",
            "applicable": "0.19"
        },
        "BB": {
            "Country": "Barbados",
            "CountryCode": "+1246",
            "rate": "1.5",
            "applicable": ""
        },
        "BY": {
            "Country": "Belarus",
            "CountryCode": "+375",
            "rate": "0.99",
            "applicable": ""
        },
        "BE": {
            "Country": "Belgium",
            "CountryCode": "+32",
            "rate": "0.99",
            "applicable": ""
        },
        "BZ": {
            "Country": "Belize",
            "CountryCode": "+501",
            "rate": "0.99",
            "applicable": ""
        },
        "BJ": {
            "Country": "Benin",
            "CountryCode": "+229",
            "rate": "0.99",
            "applicable": ""
        },
        "BM": {
            "Country": "Bermuda",
            "CountryCode": "+1441",
            "rate": "0.99",
            "applicable": ""
        },
        "BT": {
            "Country": "Bhutan",
            "CountryCode": "+975",
            "rate": "0.99",
            "applicable": ""
        },
        "BO": {
            "Country": "Bolivia",
            "CountryCode": "+591",
            "rate": "0.99",
            "applicable": ""
        },
        "BA": {
            "Country": "Bosnia And Herzegovina",
            "CountryCode": "+387",
            "rate": "0.99",
            "applicable": ""
        },
        "BW": {
            "Country": "Botswana",
            "CountryCode": "+267",
            "rate": "0.99",
            "applicable": ""
        },
        "BR": {
            "Country": "Brazil",
            "CountryCode": "+55",
            "rate": "0.99",
            "applicable": ""
        },
        "VG": {
            "Country": "British Virgin Islands",
            "CountryCode": "+1284",
            "rate": "0.99",
            "applicable": ""
        },
        "BN": {
            "Country": "Brunei Darussalam",
            "CountryCode": "+673",
            "rate": "0.99",
            "applicable": ""
        },
        "BG": {
            "Country": "Bulgaria",
            "CountryCode": "+359",
            "rate": "0.99",
            "applicable": ""
        },
        "BF": {
            "Country": "Burkina Faso",
            "CountryCode": "+226",
            "rate": "0.99",
            "applicable": ""
        },
        "BI": {
            "Country": "Burundi",
            "CountryCode": "+257",
            "rate": "1.99",
            "applicable": ""
        },
        "KH": {
            "Country": "Cambodia",
            "CountryCode": "+855",
            "rate": "0.99",
            "applicable": ""
        },
        "CM": {
            "Country": "Cameroon",
            "CountryCode": "+237",
            "rate": "0.99",
            "applicable": ""
        },
        "CA": {
            "Country": "Canada",
            "CountryCode": "+1",
            "rate": "0.99",
            "applicable": ""
        },
        "CV": {
            "Country": "Cape Verde",
            "CountryCode": "+238",
            "rate": "0.99",
            "applicable": ""
        },
        "KY": {
            "Country": "Cayman Islands",
            "CountryCode": "+1345",
            "rate": "0.99",
            "applicable": ""
        },
        "CF": {
            "Country": "Central African Republic",
            "CountryCode": "+236",
            "rate": "1.66",
            "applicable": ""
        },
        "TD": {
            "Country": "Chad",
            "CountryCode": "+235",
            "rate": "0.99",
            "applicable": ""
        },
        "CL": {
            "Country": "Chile",
            "CountryCode": "+56",
            "rate": "0.99",
            "applicable": ""
        },
        "CN": {
            "Country": "China",
            "CountryCode": "+86",
            "rate": "0.99",
            "applicable": ""
        },
        "CX": {
            "Country": "Christmas Island",
            "CountryCode": "+61",
            "rate": "1.5",
            "applicable": ""
        },
        "CC": {
            "Country": "Cocos Islands",
            "CountryCode": "+61",
            "rate": "1.5",
            "applicable": ""
        },
        "CO": {
            "Country": "Colombia",
            "CountryCode": "+57",
            "rate": "0.99",
            "applicable": ""
        },
        "KM": {
            "Country": "Comoros",
            "CountryCode": "+269",
            "rate": "1.5",
            "applicable": ""
        },
        "CG": {
            "Country": "Congo",
            "CountryCode": "+242",
            "rate": "1.5",
            "applicable": ""
        },
        "CD": {
            "Country": "Democratic Republic of Congo",
            "CountryCode": "+243",
            "rate": "1.5",
            "applicable": ""
        },
        "CK": {
            "Country": "Cook Islands",
            "CountryCode": "+682",
            "rate": "1.99",
            "applicable": ""
        },
        "CR": {
            "Country": "Costa Rica",
            "CountryCode": "+506",
            "rate": "0.99",
            "applicable": ""
        },
        "HR": {
            "Country": "Croatia",
            "CountryCode": "+385",
            "rate": "0.99",
            "applicable": ""
        },
        "CU": {
            "Country": "Cuba",
            "CountryCode": "+53",
            "rate": "2.99",
            "applicable": ""
        },
        "CY": {
            "Country": "Cyprus",
            "CountryCode": "+357",
            "rate": "0.99",
            "applicable": ""
        },
        "CZ": {
            "Country": "Czech Republic",
            "CountryCode": "+420",
            "rate": "0.99",
            "applicable": ""
        },
        "DK": {
            "Country": "Denmark",
            "CountryCode": "+45",
            "rate": "0.99",
            "applicable": ""
        },
        "DG": {
            "Country": "Diego Garcia",
            "CountryCode": "+246",
            "rate": "3.5",
            "applicable": ""
        },
        "DJ": {
            "Country": "Djibouti",
            "CountryCode": "+253",
            "rate": "0.99",
            "applicable": ""
        },
        "DM": {
            "Country": "Dominica",
            "CountryCode": "+1767",
            "rate": "0.99",
            "applicable": ""
        },
        "DO": {
            "Country": "Dominican Republic",
            "CountryCode": "+1809",
            "rate": "2.5",
            "applicable": ""
        },
        "TL": {
            "Country": "East Timor",
            "CountryCode": "Timor-Leste",
            "rate": "3.5",
            "applicable": ""
        },
        "EC": {
            "Country": "Ecuador",
            "CountryCode": "+593",
            "rate": "0.99",
            "applicable": ""
        },
        "EG": {
            "Country": "Egypt",
            "CountryCode": "+20",
            "rate": "0.99",
            "applicable": "0.35"
        },
        "SV": {
            "Country": "El Salvador",
            "CountryCode": "+503",
            "rate": "0.99",
            "applicable": ""
        },
        "GQ": {
            "Country": "Equatorial Guinea",
            "CountryCode": "+240",
            "rate": "0.99",
            "applicable": ""
        },
        "ER": {
            "Country": "Eritrea",
            "CountryCode": "+291",
            "rate": "0.99",
            "applicable": ""
        },
        "EE": {
            "Country": "Estonia",
            "CountryCode": "+372",
            "rate": "0.99",
            "applicable": ""
        },
        "ET": {
            "Country": "Ethiopia",
            "CountryCode": "+251",
            "rate": "0.99",
            "applicable": ""
        },
        "FK": {
            "Country": "Falkland Islands Malvinas",
            "CountryCode": "+500",
            "rate": "2.5",
            "applicable": ""
        },
        "FO": {
            "Country": "Faroe Islands",
            "CountryCode": "+298",
            "rate": "0.99",
            "applicable": ""
        },
        "FJ": {
            "Country": "Fiji",
            "CountryCode": "+679",
            "rate": "0.99",
            "applicable": ""
        },
        "FI": {
            "Country": "Finland",
            "CountryCode": "+358",
            "rate": "0.99",
            "applicable": ""
        },
        "FR": {
            "Country": "France",
            "CountryCode": "+33",
            "rate": "0.99",
            "applicable": ""
        },
        "GF": {
            "Country": "French Guiana",
            "CountryCode": "+594",
            "rate": "0.99",
            "applicable": ""
        },
        "PF": {
            "Country": "French Polynesia\/Tahiti",
            "CountryCode": "+689",
            "rate": "0.99",
            "applicable": ""
        },
        "GA": {
            "Country": "Gabon",
            "CountryCode": "+241",
            "rate": "1.66",
            "applicable": ""
        },
        "GM": {
            "Country": "Gambia",
            "CountryCode": "+241",
            "rate": "1.99",
            "applicable": ""
        },
        "GE": {
            "Country": "Georgia",
            "CountryCode": "+995",
            "rate": "0.99",
            "applicable": ""
        },
        "DE": {
            "Country": "Germany",
            "CountryCode": "+49",
            "rate": "0.99",
            "applicable": ""
        },
        "GH": {
            "Country": "Ghana",
            "CountryCode": "+233",
            "rate": "0.99",
            "applicable": ""
        },
        "GI": {
            "Country": "Gibraltar",
            "CountryCode": "+350",
            "rate": "0.99",
            "applicable": ""
        },
        "GR": {
            "Country": "Greece",
            "CountryCode": "+30",
            "rate": "0.99",
            "applicable": ""
        },
        "GL": {
            "Country": "Greenland",
            "CountryCode": "+299",
            "rate": "1.99",
            "applicable": ""
        },
        "GD": {
            "Country": "Grenada",
            "CountryCode": "+1473",
            "rate": "0.99",
            "applicable": ""
        },
        "GP": {
            "Country": "Guadeloupe",
            "CountryCode": "+1638",
            "rate": "0.99",
            "applicable": ""
        },
        "GU": {
            "Country": "Guam",
            "CountryCode": "+1671",
            "rate": "3.5",
            "applicable": ""
        },
        "GT": {
            "Country": "Guatemala",
            "CountryCode": "+502",
            "rate": "0.99",
            "applicable": ""
        },
        "GN": {
            "Country": "Guinea",
            "CountryCode": "+224",
            "rate": "1.66",
            "applicable": ""
        },
        "GW": {
            "Country": "Guinea-Bissau",
            "CountryCode": "+245",
            "rate": "1.66",
            "applicable": ""
        },
        "GY": {
            "Country": "Guyana",
            "CountryCode": "+592",
            "rate": "0.99",
            "applicable": ""
        },
        "HT": {
            "Country": "Haiti",
            "CountryCode": "+509",
            "rate": "0.99",
            "applicable": ""
        },
        "HN": {
            "Country": "Honduras",
            "CountryCode": "+504",
            "rate": "0.99",
            "applicable": ""
        },
        "HK": {
            "Country": "Hong Kong",
            "CountryCode": "+852",
            "rate": "0.99",
            "applicable": ""
        },
        "HU": {
            "Country": "Hungary",
            "CountryCode": "+36",
            "rate": "0.99",
            "applicable": ""
        },
        "IS": {
            "Country": "Iceland",
            "CountryCode": "+354",
            "rate": "0.99",
            "applicable": ""
        },
        "IN": {
            "Country": "India",
            "CountryCode": "+91",
            "rate": "0.99",
            "applicable": "0.15"
        },
        "ID": {
            "Country": "Indonesia",
            "CountryCode": "+62",
            "rate": "0.99",
            "applicable": "0.25"
        },
        "IR": {
            "Country": "Iran",
            "CountryCode": "+98",
            "rate": "0.99",
            "applicable": ""
        },
        "IQ": {
            "Country": "Iraq",
            "CountryCode": "+964",
            "rate": "0.99",
            "applicable": ""
        },
        "IE": {
            "Country": "Ireland",
            "CountryCode": "+353",
            "rate": "0.99",
            "applicable": ""
        },
        "IT": {
            "Country": "Italy",
            "CountryCode": "+39",
            "rate": "0.99",
            "applicable": ""
        },
        "CI": {
            "Country": "Ivory Coast",
            "CountryCode": "+225",
            "rate": "0.99",
            "applicable": ""
        },
        "JM": {
            "Country": "Jamaica",
            "CountryCode": "+1876",
            "rate": "1.5",
            "applicable": ""
        },
        "JP": {
            "Country": "Japan",
            "CountryCode": "+81",
            "rate": "3.99",
            "applicable": ""
        },
        "JO": {
            "Country": "Jordan",
            "CountryCode": "+962",
            "rate": "0.99",
            "applicable": ""
        },
        "KZ": {
            "Country": "Kazakhstan",
            "CountryCode": "+7",
            "rate": "0.99",
            "applicable": ""
        },
        "KE": {
            "Country": "Kenya",
            "CountryCode": "+254",
            "rate": "0.99",
            "applicable": ""
        },
        "KI": {
            "Country": "Kiribati",
            "CountryCode": "686",
            "rate": "0.99",
            "applicable": ""
        },
        "KP": {
            "Country": "Korea North",
            "CountryCode": "+850",
            "rate": "0.99",
            "applicable": ""
        },
        "KR": {
            "Country": "Korea South",
            "CountryCode": "+82",
            "rate": "1.99",
            "applicable": ""
        },
        "KW": {
            "Country": "Kuwait",
            "CountryCode": "+965",
            "rate": "0.99",
            "applicable": ""
        },
        "KG": {
            "Country": "Kyrgyzstan",
            "CountryCode": "+996",
            "rate": "0.99",
            "applicable": ""
        },
        "LA": {
            "Country": "Laos",
            "CountryCode": "+856",
            "rate": "0.99",
            "applicable": ""
        },
        "LV": {
            "Country": "Latvia",
            "CountryCode": "+371",
            "rate": "0.99",
            "applicable": ""
        },
        "LB": {
            "Country": "Lebanon",
            "CountryCode": "+961",
            "rate": "1.99",
            "applicable": ""
        },
        "LS": {
            "Country": "Lesotho",
            "CountryCode": "+266",
            "rate": "0.99",
            "applicable": ""
        },
        "LR": {
            "Country": "Liberia",
            "CountryCode": "+231",
            "rate": "0.99",
            "applicable": ""
        },
        "LY": {
            "Country": "Libya",
            "CountryCode": "+218",
            "rate": "1.66",
            "applicable": ""
        },
        "LI": {
            "Country": "Liechtenstein",
            "CountryCode": "+423",
            "rate": "0.99",
            "applicable": ""
        },
        "LT": {
            "Country": "Lithuania",
            "CountryCode": "+370",
            "rate": "0.99",
            "applicable": ""
        },
        "LU": {
            "Country": "Luxembourg",
            "CountryCode": "+352",
            "rate": "0.99",
            "applicable": ""
        },
        "MO": {
            "Country": "Macao, China",
            "CountryCode": "+853",
            "rate": "0.99",
            "applicable": ""
        },
        "MK": {
            "Country": "Macedonia",
            "CountryCode": "+389",
            "rate": "0.99",
            "applicable": ""
        },
        "MG": {
            "Country": "Madagascar",
            "CountryCode": "+261",
            "rate": "2.5",
            "applicable": ""
        },
        "MW": {
            "Country": "Malawi",
            "CountryCode": "+265",
            "rate": "2.99",
            "applicable": ""
        },
        "MY": {
            "Country": "Malaysia",
            "CountryCode": "+60",
            "rate": "0.99",
            "applicable": ""
        },
        "MV": {
            "Country": "Maldives",
            "CountryCode": "+960",
            "rate": "2.5",
            "applicable": ""
        },
        "ML": {
            "Country": "Mali",
            "CountryCode": "+223",
            "rate": "2.99",
            "applicable": ""
        },
        "MT": {
            "Country": "Malta",
            "CountryCode": "+356",
            "rate": "0.99",
            "applicable": ""
        },
        "MH": {
            "Country": "Marshall Islands",
            "CountryCode": "+692",
            "rate": "0.99",
            "applicable": ""
        },
        "MQ": {
            "Country": "Martinique",
            "CountryCode": "French Antilles",
            "rate": "3.99",
            "applicable": ""
        },
        "MR": {
            "Country": "Mauritania",
            "CountryCode": "+222",
            "rate": "0.99",
            "applicable": ""
        },
        "MU": {
            "Country": "Mauritius",
            "CountryCode": "+230",
            "rate": "1.66",
            "applicable": ""
        },
        "YT": {
            "Country": "Mayotte",
            "CountryCode": "+262",
            "rate": "0.99",
            "applicable": ""
        },
        "MX": {
            "Country": "Mexico",
            "CountryCode": "+52",
            "rate": "0.99",
            "applicable": ""
        },
        "FM": {
            "Country": "Micronesia",
            "CountryCode": "+691",
            "rate": "0.99",
            "applicable": ""
        },
        "MD": {
            "Country": "Moldova",
            "CountryCode": "+373",
            "rate": "0.99",
            "applicable": ""
        },
        "MC": {
            "Country": "Monaco",
            "CountryCode": "+377",
            "rate": "0.99",
            "applicable": ""
        },
        "MN": {
            "Country": "Mongolia",
            "CountryCode": "+976",
            "rate": "0.99",
            "applicable": ""
        },
        "ME": {
            "Country": "Montenegro",
            "CountryCode": "+382",
            "rate": "0.99",
            "applicable": ""
        },
        "MS": {
            "Country": "Montserrat",
            "CountryCode": "+1664",
            "rate": "0.99",
            "applicable": ""
        },
        "MA": {
            "Country": "Morocco",
            "CountryCode": "+212",
            "rate": "1.5",
            "applicable": ""
        },
        "MZ": {
            "Country": "Mozambique",
            "CountryCode": "+258",
            "rate": "1.66",
            "applicable": ""
        },
        "MM": {
            "Country": "Myanmar",
            "CountryCode": "Burma",
            "rate": "0.99",
            "applicable": ""
        },
        "NA": {
            "Country": "Namibia",
            "CountryCode": "+264",
            "rate": "0.99",
            "applicable": ""
        },
        "NR": {
            "Country": "Nauru",
            "CountryCode": "+674",
            "rate": "0.99",
            "applicable": ""
        },
        "NP": {
            "Country": "Nepal",
            "CountryCode": "+977",
            "rate": "0.99",
            "applicable": "0.20"
        },
        "NL": {
            "Country": "Netherlands",
            "CountryCode": "+31",
            "rate": "0.99",
            "applicable": "0.45"
        },
        "AN\u00a0": {
            "Country": "Netherlands Antilles",
            "CountryCode": "+599",
            "rate": "0.99",
            "applicable": ""
        },
        "NC": {
            "Country": "New Caledonia",
            "CountryCode": "+687",
            "rate": "0.99",
            "applicable": ""
        },
        "NZ": {
            "Country": "New Zealand",
            "CountryCode": "+64",
            "rate": "0.99",
            "applicable": ""
        },
        "NI": {
            "Country": "Nicaragua",
            "CountryCode": "+505",
            "rate": "0.99",
            "applicable": ""
        },
        "NE": {
            "Country": "Niger",
            "CountryCode": "+227",
            "rate": "0.99",
            "applicable": ""
        },
        "NG": {
            "Country": "Nigeria",
            "CountryCode": "+234",
            "rate": "0.99",
            "applicable": ""
        },
        "NU": {
            "Country": "Niue",
            "CountryCode": "+683",
            "rate": "2.5",
            "applicable": ""
        },
        "NF": {
            "Country": "Norfolk Island",
            "CountryCode": "+672",
            "rate": "3.5",
            "applicable": ""
        },
        "MP": {
            "Country": "Northern Mariana Islands",
            "CountryCode": "+1670",
            "rate": "3.99",
            "applicable": ""
        },
        "NO": {
            "Country": "Norway",
            "CountryCode": "+47",
            "rate": "3.99",
            "applicable": ""
        },
        "OM": {
            "Country": "Oman",
            "CountryCode": "+968",
            "rate": "0.99",
            "applicable": ""
        },
        "PK": {
            "Country": "Pakistan",
            "CountryCode": "+92",
            "rate": "0.99",
            "applicable": "0.45"
        },
        "PW": {
            "Country": "Palau",
            "CountryCode": "+680",
            "rate": "0.99",
            "applicable": "0.45"
        },
        "PS": {
            "Country": "Palestine",
            "CountryCode": "+972",
            "rate": "0.99",
            "applicable": ""
        },
        "PA": {
            "Country": "Panama",
            "CountryCode": "+507",
            "rate": "0.99",
            "applicable": ""
        },
        "PG": {
            "Country": "Papua New Guinea",
            "CountryCode": "+675",
            "rate": "1.99",
            "applicable": ""
        },
        "PY": {
            "Country": "Paraguay",
            "CountryCode": "+595",
            "rate": "0.99",
            "applicable": ""
        },
        "PE": {
            "Country": "Peru",
            "CountryCode": "+51",
            "rate": "0.99",
            "applicable": ""
        },
        "PH": {
            "Country": "Philippines",
            "CountryCode": "+63",
            "rate": "0.99",
            "applicable": "0.45"
        },
        "PL": {
            "Country": "Poland",
            "CountryCode": "+48",
            "rate": "0.99",
            "applicable": ""
        },
        "PT": {
            "Country": "Portugal",
            "CountryCode": "+351",
            "rate": "0.99",
            "applicable": ""
        },
        "PR": {
            "Country": "Puerto Rico",
            "CountryCode": "+1787",
            "rate": "0.99",
            "applicable": ""
        },
        "RE": {
            "Country": "Reunion",
            "CountryCode": "+262",
            "rate": "1.5",
            "applicable": ""
        },
        "RO": {
            "Country": "Romania",
            "CountryCode": "+40",
            "rate": "0.99",
            "applicable": ""
        },
        "RU": {
            "Country": "Russia",
            "CountryCode": "+7",
            "rate": "0.99",
            "applicable": ""
        },
        "RW": {
            "Country": "Rwanda",
            "CountryCode": "+250",
            "rate": "0.99",
            "applicable": ""
        },
        "BL": {
            "Country": "Saint Barthelemy",
            "CountryCode": "+590",
            "rate": "3.99",
            "applicable": ""
        },
        "SH": {
            "Country": "Saint Helena",
            "CountryCode": "+290",
            "rate": "2.8",
            "applicable": ""
        },
        "KN": {
            "Country": "Saint Kitts And Nevis",
            "CountryCode": "+1869",
            "rate": "2.5",
            "applicable": ""
        },
        "LC": {
            "Country": "Saint Lucia",
            "CountryCode": "+1758",
            "rate": "0.99",
            "applicable": ""
        },
        "MF": {
            "Country": "Saint Martin",
            "CountryCode": "+1599",
            "rate": "0.99",
            "applicable": ""
        },
        "PM": {
            "Country": "Saint Pierre And Miquelon",
            "CountryCode": "+508",
            "rate": "2.5",
            "applicable": ""
        },
        "VC": {
            "Country": "Saint Vincent And The Grenadines",
            "CountryCode": "+1784",
            "rate": "0.99",
            "applicable": ""
        },
        "SM": {
            "Country": "San Marino",
            "CountryCode": "+378",
            "rate": "0.99",
            "applicable": ""
        },
        "ST": {
            "Country": "Sao Tome And Principe",
            "CountryCode": "+239",
            "rate": "2.5",
            "applicable": ""
        },
        "SA": {
            "Country": "Saudi Arabia",
            "CountryCode": "+966",
            "rate": "0.99",
            "applicable": "0.45"
        },
        "SN": {
            "Country": "Senegal",
            "CountryCode": "+221",
            "rate": "0.99",
            "applicable": ""
        },
        "RS": {
            "Country": "Serbia",
            "CountryCode": "+381",
            "rate": "0.99",
            "applicable": ""
        },
        "SC": {
            "Country": "Seychelles",
            "CountryCode": "+248",
            "rate": "1.99",
            "applicable": ""
        },
        "SL": {
            "Country": "Sierra Leone",
            "CountryCode": "+232",
            "rate": "1.99",
            "applicable": ""
        },
        "SG": {
            "Country": "Singapore",
            "CountryCode": "+65",
            "rate": "0.99",
            "applicable": ""
        },
        "SK": {
            "Country": "Slovakia",
            "CountryCode": "+421",
            "rate": "0.99",
            "applicable": ""
        },
        "SI": {
            "Country": "Slovenia",
            "CountryCode": "+386",
            "rate": "0.99",
            "applicable": ""
        },
        "SB": {
            "Country": "Solomon Islands",
            "CountryCode": "+677",
            "rate": "2.99",
            "applicable": ""
        },
        "SO": {
            "Country": "Somalia",
            "CountryCode": "+252",
            "rate": "1.5",
            "applicable": ""
        },
        "ZA": {
            "Country": "South Africa",
            "CountryCode": "+27",
            "rate": "0.99",
            "applicable": ""
        },
        "SS": {
            "Country": "South Sudan",
            "CountryCode": "+211",
            "rate": "0.99",
            "applicable": ""
        },
        "ES": {
            "Country": "Spain",
            "CountryCode": "+34",
            "rate": "0.99",
            "applicable": ""
        },
        "LK": {
            "Country": "Sri Lanka",
            "CountryCode": "+94",
            "rate": "0.99",
            "applicable": "0.45"
        },
        "SD": {
            "Country": "Sudan",
            "CountryCode": "+249",
            "rate": "0.99",
            "applicable": "0.45"
        },
        "SR": {
            "Country": "Suriname",
            "CountryCode": "+597",
            "rate": "0.99",
            "applicable": ""
        },
        "SZ": {
            "Country": "Swaziland",
            "CountryCode": "+268",
            "rate": "0.99",
            "applicable": ""
        },
        "SE": {
            "Country": "Sweden",
            "CountryCode": "+46",
            "rate": "0.99",
            "applicable": ""
        },
        "CH": {
            "Country": "Switzerland",
            "CountryCode": "+41",
            "rate": "0.99",
            "applicable": ""
        },
        "SY": {
            "Country": "Syria",
            "CountryCode": "+963",
            "rate": "0.99",
            "applicable": "0.45"
        },
        "TW": {
            "Country": "Taiwan, China",
            "CountryCode": "+886",
            "rate": "0.99",
            "applicable": ""
        },
        "TJ": {
            "Country": "Tajikistan",
            "CountryCode": "+992",
            "rate": "0.99",
            "applicable": ""
        },
        "TZ": {
            "Country": "Tanzania",
            "CountryCode": "+255",
            "rate": "0.99",
            "applicable": ""
        },
        "TH": {
            "Country": "Thailand",
            "CountryCode": "+66",
            "rate": "0.99",
            "applicable": "0.45"
        },
        "TG": {
            "Country": "Togo",
            "CountryCode": "+228",
            "rate": "0.99",
            "applicable": ""
        },
        "TK": {
            "Country": "Tokelau",
            "CountryCode": "+690",
            "rate": "3.5",
            "applicable": ""
        },
        "TO": {
            "Country": "Tonga",
            "CountryCode": "+676",
            "rate": "0.99",
            "applicable": ""
        },
        "TT": {
            "Country": "Trinidad And Tobago",
            "CountryCode": "+1868",
            "rate": "0.99",
            "applicable": ""
        },
        "TN": {
            "Country": "Tunisia",
            "CountryCode": "+216",
            "rate": "1.66",
            "applicable": ""
        },
        "TR": {
            "Country": "Turkey",
            "CountryCode": "+90",
            "rate": "0.99",
            "applicable": "0.45"
        },
        "TM": {
            "Country": "Turkmenistan",
            "CountryCode": "+993",
            "rate": "0.99",
            "applicable": ""
        },
        "TC": {
            "Country": "Turks And Caicos Islands",
            "CountryCode": "+1649",
            "rate": "0.99",
            "applicable": ""
        },
        "TV": {
            "Country": "Tuvalu",
            "CountryCode": "+688",
            "rate": "3.5",
            "applicable": ""
        },
        "UG": {
            "Country": "Uganda",
            "CountryCode": "+256",
            "rate": "0.99",
            "applicable": ""
        },
        "UA": {
            "Country": "Ukraine",
            "CountryCode": "+380",
            "rate": "0.99",
            "applicable": ""
        },
        "AE": {
            "Country": "United Arab Emirates",
            "CountryCode": "+971",
            "rate": "0.99",
            "applicable": "0.45"
        },
        "GB": {
            "Country": "United Kingdom",
            "CountryCode": "+44",
            "rate": "0.99",
            "applicable": ""
        },
        "US": {
            "Country": "United States Of America",
            "CountryCode": "+1",
            "rate": "0.99",
            "applicable": ""
        },
        "VI": {
            "Country": "United States Virgin Islands",
            "CountryCode": "+1340",
            "rate": "0.99",
            "applicable": ""
        },
        "UY": {
            "Country": "Uruguay",
            "CountryCode": "+598",
            "rate": "0.99",
            "applicable": ""
        },
        "UZ": {
            "Country": "Uzbekistan",
            "CountryCode": "+998",
            "rate": "0.99",
            "applicable": ""
        },
        "VU": {
            "Country": "Vanuatu",
            "CountryCode": "+678",
            "rate": "1.66",
            "applicable": ""
        },
        "VA": {
            "Country": "Vatican",
            "CountryCode": "+39",
            "rate": "0.99",
            "applicable": ""
        },
        "VE": {
            "Country": "Venezuela",
            "CountryCode": "+58",
            "rate": "0.99",
            "applicable": ""
        },
        "VN": {
            "Country": "Vietnam",
            "CountryCode": "+84",
            "rate": "0.99",
            "applicable": ""
        },
        "WF": {
            "Country": "Wallis And Futuna",
            "CountryCode": "+681",
            "rate": "2.5",
            "applicable": ""
        },
        "WS": {
            "Country": "Western Samoa \/ Samoa Country",
            "CountryCode": "+685",
            "rate": "3.99",
            "applicable": ""
        },
        "YE": {
            "Country": "Yemen",
            "CountryCode": "+967",
            "rate": "0.99",
            "applicable": ""
        },
        "ZM": {
            "Country": "Zambia",
            "CountryCode": "+260",
            "rate": "0.99",
            "applicable": ""
        },
        "ZW": {
            "Country": "Zimbabwe",
            "CountryCode": "+263",
            "rate": "1.66",
            "applicable": ""
        }
    };

    var oldID = "";
    var substringMatcher = function (strs) {
        return function findMatches(q, cb) {
            var matches, substringRegex;
            matches = [];
            substrRegex = new RegExp(q, 'i');
            $.each(strs, function (i, str) {
                if (substrRegex.test(str)) {
                    matches.push(str);
                }
            });
            cb(matches);
        };
    };
    var keys = [];
    $.each(countriesCode, function (index, value) {
        keys.push(index);
    });
    $('#search_for_country .typeahead').typeahead({}, {
        name: 'search',
        source: substringMatcher(keys)
    });
    $("#shahry_international_world_page").mapael({
        map: {
            name: "world",
            zoom: {
                enabled: true,
                maxLevel: 10
            },
            defaultArea: {
                attrs: {
                    fill: "#fff",
                    stroke: "#a9a9a9"
                },
                attrsHover: {
                    fill: "#ccc"
                },
                eventHandlers: {
                    click: function (e, id, mapElem, textElem) {
                        var geocoder = new google.maps.Geocoder();
                        geocoder
                            .geocode({
                                    'address': countriesByCode[id]["Country"]
                                },
                                function (results,
                                          status) {
                                    if (status == google.maps.GeocoderStatus.OK) {
                                        $("#shahry_international_world_page").trigger(
                                            'zoom', {
                                                level: 3,
                                                latitude: results[0].geometry.location
                                                    .lat(),
                                                longitude: results[0].geometry.location
                                                    .lng(),
                                                animDuration: 200
                                            });
                                    } else {
                                        $(
                                            "#shahry_international_world_page")
                                            .trigger(
                                                'zoom', {
                                                    level: 0
                                                });
                                    }
                                });

                        var newData = {
                            'areas': {}
                        };
                        // newData.map.defaultArea.attrs.fill =
                        // "#eeefef";
                        if (mapElem.originalAttrs.fill == "#ed1c24") {
                            return false;
                            newData.areas[id] = {
                                attrs: {
                                    fill: "#fff"
                                },
                                attrsHover: {
                                    fill: "#ccc"
                                }
                            };
                        } else {
                            newData.areas[id] = {
                                attrs: {
                                    fill: "#ed1c24"
                                },
                                attrsHover: {
                                    fill: "#ed1c24"
                                }
                            };
                        }
                        newData.areas[oldID] = {
                            attrs: {
                                fill: "#fff"
                            },
                            attrsHover: {
                                fill: "#ccc"
                            }
                        };
                        oldID = id;
                        $("#shahry_international_world_page")
                            .trigger('update', [newData]);

                        updateContent(oldID);
                    },
                    touchstart: function (e, id, mapElem, textElem) {
                        var geocoder = new google.maps.Geocoder();
                        geocoder
                            .geocode({
                                    'address': countriesByCode[id]["Country"]
                                },
                                function (results,
                                          status) {
                                    if (status == google.maps.GeocoderStatus.OK) {
                                        $(
                                            "#shahry_international_world_page")
                                            .trigger(
                                                'zoom', {
                                                    level: 3,
                                                    latitude: results[0].geometry.location
                                                        .lat(),
                                                    longitude: results[0].geometry.location
                                                        .lng(),
                                                    animDuration: 200
                                                });
                                    } else {
                                        $(
                                            "#shahry_international_world_page")
                                            .trigger(
                                                'zoom', {
                                                    level: 0
                                                });
                                    }
                                });

                        var newData = {
                            'areas': {}
                        };
                        // newData.map.defaultArea.attrs.fill =
                        // "#eeefef";
                        if (mapElem.originalAttrs.fill == "#ed1c24") {
                            return false;
                            newData.areas[id] = {
                                attrs: {
                                    fill: "#fff"
                                },
                                attrsHover: {
                                    fill: "#ccc"
                                }
                            };
                        } else {
                            newData.areas[id] = {
                                attrs: {
                                    fill: "#ed1c24"
                                },
                                attrsHover: {
                                    fill: "#ed1c24"
                                }
                            };
                        }
                        newData.areas[oldID] = {
                            attrs: {
                                fill: "#fff"
                            },
                            attrsHover: {
                                fill: "#ccc"
                            }
                        };
                        oldID = id;
                        $("#shahry_international_world_page")
                            .trigger('update', [newData]);

                        updateContent(oldID);
                    }
                }
            }
        },

        areas: {
            "AD": {
                tooltip: {
                    content: "Andorra"
                }
            },
            "AE": {
                tooltip: {
                    content: "United Arab Emirates"
                }
            },
            "AF": {
                tooltip: {
                    content: "Afghanistan"
                }
            },
            "AR": {
                tooltip: {
                    content: "Argentina"
                }
            },
            "AI": {
                tooltip: {
                    content: "Anguilla"
                }
            },
            "AL": {
                tooltip: {
                    content: "Albania"
                }
            },
            "AW": {
                tooltip: {
                    content: "Aruba"
                }
            },
            "AN": {
                tooltip: {
                    content: "Netherlands Antilles"
                }
            },
            "AO": {
                tooltip: {
                    content: "Angola"
                }
            },
            "AQ": {
                tooltip: {
                    content: "Antarctica"
                }
            },
            "AM": {
                tooltip: {
                    content: "Armenia"
                }
            },
            "AS": {
                tooltip: {
                    content: "American Samoa"
                }
            },
            "AT": {
                tooltip: {
                    content: "Austria"
                }
            },
            "AU": {
                tooltip: {
                    content: "Australia"
                }
            },
            "AZ": {
                tooltip: {
                    content: "Azerbaijan"
                }
            },
            "BA": {
                tooltip: {
                    content: "Bosnia And Herzegovina"
                }
            },
            "BB": {
                tooltip: {
                    content: "Barbados"
                }
            },
            "BD": {
                tooltip: {
                    content: "Bangladesh"
                }
            },
            "BE": {
                tooltip: {
                    content: "Belgium"
                }
            },
            "BF": {
                tooltip: {
                    content: "Burkina Faso"
                }
            },
            "BG": {
                tooltip: {
                    content: "Bulgaria"
                }
            },
            "BH": {
                tooltip: {
                    content: "Bahrain"
                }
            },
            "BI": {
                tooltip: {
                    content: "Burundi"
                }
            },
            "BJ": {
                tooltip: {
                    content: "Benin"
                }
            },
            "BL": {
                tooltip: {
                    content: "Saint Barthelemy"
                }
            },
            "BM": {
                tooltip: {
                    content: "Bermuda"
                }
            },
            "BN": {
                tooltip: {
                    content: "Brunei Darussalam"
                }
            },
            "BO": {
                tooltip: {
                    content: "Bolivia"
                }
            },
            "BR": {
                tooltip: {
                    content: "Brazil"
                }
            },
            "BS": {
                tooltip: {
                    content: "Bahamas"
                }
            },
            "BT": {
                tooltip: {
                    content: "Bhutan"
                }
            },
            "BW": {
                tooltip: {
                    content: "Botswana"
                }
            },
            "BY": {
                tooltip: {
                    content: "Belarus"
                }
            },
            "BZ": {
                tooltip: {
                    content: "Belize"
                }
            },
            "CA": {
                tooltip: {
                    content: "Canada"
                }
            },
            "CC": {
                tooltip: {
                    content: "Cocos Islands"
                }
            },
            "CD": {
                tooltip: {
                    content: "Democratic Republic of Congo"
                }
            },
            "CF": {
                tooltip: {
                    content: "Central African Republic"
                }
            },
            "CG": {
                tooltip: {
                    content: "Congo"
                }
            },
            "CH": {
                tooltip: {
                    content: "Switzerland"
                }
            },
            "CK": {
                tooltip: {
                    content: "Cook Islands"
                }
            },
            "CL": {
                tooltip: {
                    content: "Chile"
                }
            },
            "KH": {
                tooltip: {
                    content: "Cambodia"
                }
            },
            "CM": {
                tooltip: {
                    content: "Cameroon"
                }
            },
            "CN": {
                tooltip: {
                    content: "China"
                }
            },
            "CO": {
                tooltip: {
                    content: "Colombia"
                }
            },
            "CR": {
                tooltip: {
                    content: "Costa Rica"
                }
            },
            "CU": {
                tooltip: {
                    content: "Cuba"
                }
            },
            "CV": {
                tooltip: {
                    content: "Cape Verde"
                }
            },
            "CX": {
                tooltip: {
                    content: "Christmas Island"
                }
            },
            "CY": {
                tooltip: {
                    content: "Cyprus"
                }
            },
            "CZ": {
                tooltip: {
                    content: "Czech Republic"
                }
            },
            "DE": {
                tooltip: {
                    content: "Germany"
                }
            },
            "DG": {
                tooltip: {
                    content: "Diego Garcia"
                }
            },
            "DJ": {
                tooltip: {
                    content: "Djibouti"
                }
            },
            "DK": {
                tooltip: {
                    content: "Denmark"
                }
            },
            "DM": {
                tooltip: {
                    content: "Dominica"
                }
            },
            "DO": {
                tooltip: {
                    content: "Dominican Republic"
                }
            },
            "DZ": {
                tooltip: {
                    content: "Algeria"
                }
            },
            "EC": {
                tooltip: {
                    content: "Ecuador"
                }
            },
            "EE": {
                tooltip: {
                    content: "Estonia"
                }
            },
            "EG": {
                tooltip: {
                    content: "Egypt"
                }
            },
            "ER": {
                tooltip: {
                    content: "Eritrea"
                }
            },
            "ES": {
                tooltip: {
                    content: "Spain"
                }
            },
            "ET": {
                tooltip: {
                    content: "Ethiopia"
                }
            },
            "FI": {
                tooltip: {
                    content: "Finland"
                }
            },
            "FJ": {
                tooltip: {
                    content: "Fiji"
                }
            },
            "FK": {
                tooltip: {
                    content: "Falkland Islands Malvinas"
                }
            },
            "FM": {
                tooltip: {
                    content: "Micronesia"
                }
            },
            "FO": {
                tooltip: {
                    content: "Faroe Islands"
                }
            },
            "FR": {
                tooltip: {
                    content: "France"
                }
            },
            "GA": {
                tooltip: {
                    content: "Gabon"
                }
            },
            "GB": {
                tooltip: {
                    content: "United Kingdom"
                }
            },
            "GP": {
                tooltip: {
                    content: "Guadeloupe"
                }
            },
            "GE": {
                tooltip: {
                    content: "Georgia"
                }
            },
            "GF": {
                tooltip: {
                    content: "French Guiana"
                }
            },
            "GI": {
                tooltip: {
                    content: "Gibraltar"
                }
            },
            "GR": {
                tooltip: {
                    content: "Greece"
                }
            },
            "GD": {
                tooltip: {
                    content: "Grenada"
                }
            },
            "GM": {
                tooltip: {
                    content: "Gambia"
                }
            },
            "GU": {
                tooltip: {
                    content: "Guam"
                }
            },
            "GQ": {
                tooltip: {
                    content: "Equatorial Guinea"
                }
            },
            "GL": {
                tooltip: {
                    content: "Greenland"
                }
            },
            "GN": {
                tooltip: {
                    content: "Guinea"
                }
            },
            "GT": {
                tooltip: {
                    content: "Guatemala"
                }
            },
            "GW": {
                tooltip: {
                    content: "Guinea-Bissau"
                }
            },
            "GY": {
                tooltip: {
                    content: "Guyana"
                }
            },
            "HK": {
                tooltip: {
                    content: "Hong Kong"
                }
            },
            "HN": {
                tooltip: {
                    content: "Honduras"
                }
            },
            "HR": {
                tooltip: {
                    content: "Croatia"
                }
            },
            "HT": {
                tooltip: {
                    content: "Haiti"
                }
            },
            "HU": {
                tooltip: {
                    content: "Hungary"
                }
            },
            "ID": {
                tooltip: {
                    content: "Indonesia"
                }
            },
            "IE": {
                tooltip: {
                    content: "Ireland"
                }
            },
            "IN": {
                tooltip: {
                    content: "India"
                }
            },
            "IQ": {
                tooltip: {
                    content: "Iraq"
                }
            },
            "IR": {
                tooltip: {
                    content: "Iran"
                }
            },
            "IS": {
                tooltip: {
                    content: "Iceland"
                }
            },
            "IT": {
                tooltip: {
                    content: "Italy"
                }
            },
            "JP": {
                tooltip: {
                    content: "Japan"
                }
            },
            "CI": {
                tooltip: {
                    content: "Ivory Coast"
                }
            },
            "JO": {
                tooltip: {
                    content: "Jordan"
                }
            },
            "JM": {
                tooltip: {
                    content: "Jamaica"
                }
            },
            "KE": {
                tooltip: {
                    content: "Kenya"
                }
            },
            "KG": {
                tooltip: {
                    content: "Kyrgyzstan"
                }
            },
            "KI": {
                tooltip: {
                    content: "Kiribati"
                }
            },
            "KM": {
                tooltip: {
                    content: "Comoros"
                }
            },
            "KN": {
                tooltip: {
                    content: "Saint Kitts And Nevis"
                }
            },
            "KP": {
                tooltip: {
                    content: "Korea North"
                }
            },
            "KR": {
                tooltip: {
                    content: "Korea South"
                }
            },
            "KW": {
                tooltip: {
                    content: "Kuwait"
                }
            },
            "KY": {
                tooltip: {
                    content: "Cayman Islands"
                }
            },
            "KZ": {
                tooltip: {
                    content: "Kazakhstan"
                }
            },
            "LA": {
                tooltip: {
                    content: "Laos"
                }
            },
            "LB": {
                tooltip: {
                    content: "Lebanon"
                }
            },
            "LC": {
                tooltip: {
                    content: "Saint Lucia"
                }
            },
            "LI": {
                tooltip: {
                    content: "Liechtenstein"
                }
            },
            "LK": {
                tooltip: {
                    content: "Sri Lanka"
                }
            },
            "LR": {
                tooltip: {
                    content: "Liberia"
                }
            },
            "LS": {
                tooltip: {
                    content: "Lesotho"
                }
            },
            "LT": {
                tooltip: {
                    content: "Lithuania"
                }
            },
            "LU": {
                tooltip: {
                    content: "Luxembourg"
                }
            },
            "LV": {
                tooltip: {
                    content: "Latvia"
                }
            },
            "LY": {
                tooltip: {
                    content: "Libya"
                }
            },
            "MA": {
                tooltip: {
                    content: "Morocco"
                }
            },
            "MC": {
                tooltip: {
                    content: "Monaco"
                }
            },
            "MD": {
                tooltip: {
                    content: "Moldova"
                }
            },
            "ME": {
                tooltip: {
                    content: "Montenegro"
                }
            },
            "MF": {
                tooltip: {
                    content: "Saint Martin"
                }
            },
            "MG": {
                tooltip: {
                    content: "Madagascar"
                }
            },
            "MH": {
                tooltip: {
                    content: "Marshall Islands"
                }
            },
            "MK": {
                tooltip: {
                    content: "Macedonia"
                }
            },
            "ML": {
                tooltip: {
                    content: "Mali"
                }
            },
            "MM": {
                tooltip: {
                    content: "Myanmar"
                }
            },
            "MN": {
                tooltip: {
                    content: "Mongolia"
                }
            },
            "MO": {
                tooltip: {
                    content: "Macao, China"
                }
            },
            "MP": {
                tooltip: {
                    content: "Northern Mariana Islands"
                }
            },
            "MQ": {
                tooltip: {
                    content: "Martinique"
                }
            },
            "MR": {
                tooltip: {
                    content: "Mauritania"
                }
            },
            "MS": {
                tooltip: {
                    content: "Montserrat"
                }
            },
            "MT": {
                tooltip: {
                    content: "Malta"
                }
            },
            "MU": {
                tooltip: {
                    content: "Mauritius"
                }
            },
            "MV": {
                tooltip: {
                    content: "Maldives"
                }
            },
            "MW": {
                tooltip: {
                    content: "Malawi"
                }
            },
            "MX": {
                tooltip: {
                    content: "Mexico"
                }
            },
            "MY": {
                tooltip: {
                    content: "Malaysia"
                }
            },
            "MZ": {
                tooltip: {
                    content: "Mozambique"
                }
            },
            "NA": {
                tooltip: {
                    content: "Namibia"
                }
            },
            "NC": {
                tooltip: {
                    content: "New Caledonia"
                }
            },
            "NE": {
                tooltip: {
                    content: "Niger"
                }
            },
            "NF": {
                tooltip: {
                    content: "Norfolk Island"
                }
            },
            "NG": {
                tooltip: {
                    content: "Nigeria"
                }
            },
            "NI": {
                tooltip: {
                    content: "Nicaragua"
                }
            },
            "NL": {
                tooltip: {
                    content: "Netherlands"
                }
            },
            "NO": {
                tooltip: {
                    content: "Norway"
                }
            },
            "NP": {
                tooltip: {
                    content: "Nepal"
                }
            },
            "NR": {
                tooltip: {
                    content: "Nauru"
                }
            },
            "NU": {
                tooltip: {
                    content: "Niue"
                }
            },
            "NZ": {
                tooltip: {
                    content: "New Zealand"
                }
            },
            "OM": {
                tooltip: {
                    content: "Oman"
                }
            },
            "PA": {
                tooltip: {
                    content: "Panama"
                }
            },
            "PE": {
                tooltip: {
                    content: "Peru"
                }
            },
            "PF": {
                tooltip: {
                    content: "French Polynesia\/Tahiti"
                }
            },
            "PG": {
                tooltip: {
                    content: "Papua New Guinea"
                }
            },
            "PH": {
                tooltip: {
                    content: "Philippines"
                }
            },
            "PK": {
                tooltip: {
                    content: "Pakistan"
                }
            },
            "PL": {
                tooltip: {
                    content: "Poland"
                }
            },
            "PM": {
                tooltip: {
                    content: "Saint Pierre And Miquelon"
                }
            },
            "PR": {
                tooltip: {
                    content: "Puerto Rico"
                }
            },
            "PS": {
                tooltip: {
                    content: "Palestine"
                }
            },
            "PT": {
                tooltip: {
                    content: "Portugal"
                }
            },
            "PW": {
                tooltip: {
                    content: "Palau"
                }
            },
            "PY": {
                tooltip: {
                    content: "Paraguay"
                }
            },
            "RE": {
                tooltip: {
                    content: "Reunion"
                }
            },
            "RO": {
                tooltip: {
                    content: "Romania"
                }
            },
            "RS": {
                tooltip: {
                    content: "Serbia"
                }
            },
            "RU": {
                tooltip: {
                    content: "Russia"
                }
            },
            "RW": {
                tooltip: {
                    content: "Rwanda"
                }
            },
            "SA": {
                tooltip: {
                    content: "Saudi Arabia"
                }
            },
            "SB": {
                tooltip: {
                    content: "Solomon Islands"
                }
            },
            "SC": {
                tooltip: {
                    content: "Seychelles"
                }
            },
            "SD": {
                tooltip: {
                    content: "Sudan"
                }
            },
            "SE": {
                tooltip: {
                    content: "Sweden"
                }
            },
            "SG": {
                tooltip: {
                    content: "Singapore"
                }
            },
            "SH": {
                tooltip: {
                    content: "Saint Helena"
                }
            },
            "SI": {
                tooltip: {
                    content: "Slovenia"
                }
            },
            "SK": {
                tooltip: {
                    content: "Slovakia"
                }
            },
            "SL": {
                tooltip: {
                    content: "Sierra Leone"
                }
            },
            "SM": {
                tooltip: {
                    content: "San Marino"
                }
            },
            "SN": {
                tooltip: {
                    content: "Senegal"
                }
            },
            "SO": {
                tooltip: {
                    content: "Somalia"
                }
            },
            "SR": {
                tooltip: {
                    content: "Suriname"
                }
            },
            "SS": {
                tooltip: {
                    content: "South Sudan"
                }
            },
            "ST": {
                tooltip: {
                    content: "Sao Tome And Principe"
                }
            },
            "SV": {
                tooltip: {
                    content: "El Salvador"
                }
            },
            "SY": {
                tooltip: {
                    content: "Syria"
                }
            },
            "SZ": {
                tooltip: {
                    content: "Swaziland"
                }
            },
            "TC": {
                tooltip: {
                    content: "Turks And Caicos Islands"
                }
            },
            "TD": {
                tooltip: {
                    content: "Chad"
                }
            },
            "TG": {
                tooltip: {
                    content: "Togo"
                }
            },
            "TH": {
                tooltip: {
                    content: "Thailand"
                }
            },
            "TJ": {
                tooltip: {
                    content: "Tajikistan"
                }
            },
            "TK": {
                tooltip: {
                    content: "Tokelau"
                }
            },
            "TL": {
                tooltip: {
                    content: "East Timor"
                }
            },
            "TM": {
                tooltip: {
                    content: "Turkmenistan"
                }
            },
            "TN": {
                tooltip: {
                    content: "Tunisia"
                }
            },
            "TO": {
                tooltip: {
                    content: "Tonga"
                }
            },
            "TR": {
                tooltip: {
                    content: "Turkey"
                }
            },
            "TT": {
                tooltip: {
                    content: "Trinidad And Tobago"
                }
            },
            "TV": {
                tooltip: {
                    content: "Tuvalu"
                }
            },
            "TW": {
                tooltip: {
                    content: "Taiwan, China"
                }
            },
            "TZ": {
                tooltip: {
                    content: "Tanzania"
                }
            },
            "UA": {
                tooltip: {
                    content: "Ukraine"
                }
            },
            "UG": {
                tooltip: {
                    content: "Uganda"
                }
            },
            "US": {
                tooltip: {
                    content: "United States Of America"
                }
            },
            "UY": {
                tooltip: {
                    content: "Uruguay"
                }
            },
            "UZ": {
                tooltip: {
                    content: "Uzbekistan"
                }
            },
            "VA": {
                tooltip: {
                    content: "Vatican"
                }
            },
            "VC": {
                tooltip: {
                    content: "Saint Vincent And The Grenadines"
                }
            },
            "VE": {
                tooltip: {
                    content: "Venezuela"
                }
            },
            "VG": {
                tooltip: {
                    content: "British Virgin Islands"
                }
            },
            "VI": {
                tooltip: {
                    content: "United States Virgin Islands"
                }
            },
            "VN": {
                tooltip: {
                    content: "Vietnam"
                }
            },
            "VU": {
                tooltip: {
                    content: "Vanuatu"
                }
            },
            "WF": {
                tooltip: {
                    content: "Wallis And Futuna"
                }
            },
            "WS": {
                tooltip: {
                    content: "Western Samoa \/ Samoa Country"
                }
            },
            "YE": {
                tooltip: {
                    content: "Yemen"
                }
            },
            "YT": {
                tooltip: {
                    content: "Mayotte"
                }
            },
            "ZA": {
                tooltip: {
                    content: "South Africa"
                }
            },
            "ZM": {
                tooltip: {
                    content: "Zambia"
                }
            },
            "ZW": {
                tooltip: {
                    content: "Zimbabwe"
                }
            },
            "AG": {
                tooltip: {
                    content: "Antigua And Barbuda"
                }
            },
            "GH": {
                tooltip: {
                    content: "Ghana"
                }
            }
        }
    });
    $(".mapTooltip").remove();
    $("#shahry_international_accordion a").click(
        function () {
            $("#shahry_international_accordion .panel-heading").find(
                ".glyphicon").not($(this).find(".glyphicon")).addClass(
                "glyphicon-plus").removeClass("glyphicon-minus");
            $(this).find(".glyphicon").toggleClass("glyphicon-minus",
                "glyphicon-plus");
        });
    $("#search_for_country .tt-dataset-search").on(
        "click",
        "div",
        function () {
            var countryName = $(this).text();
            var country = countriesCode[countryName];
            var updatedOptions = {
                'areas': {}
            };
            updatedOptions.areas[country["CountryID"]] = {
                attrs: {
                    fill: "#ed1c24"
                },
                attrsHover: {
                    fill: "#ed1c24"
                }
            };
            if (oldID) {
                updatedOptions.areas[oldID] = {
                    attrs: {
                        fill: "#fff"
                    },
                    attrsHover: {
                        fill: "#ccc"
                    }
                };
            }
            oldID = country["CountryID"];
            $("#shahry_international_world_page").trigger('update', [updatedOptions, {}, {}, {
                animDuration: 1000
            }]);

            var geocoder = new google.maps.Geocoder();
            geocoder.geocode({
                'address': countryName
            }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {

                    $("#shahry_international_world_page").trigger('zoom', {
                        level: 50,
                        latitude: results[0].geometry.location.lat(),
                        longitude: results[0].geometry.location.lng(),
                        animDuration: 200
                    });
                } else {
                    $("#shahry_international_world_page").trigger('zoom', {
                        level: 0
                    });
                }
            });

            updateContent(oldID);
        });


    $("#search_for_country .glyphicon-search").bind("click", function () {
        var countryName = $("#search_for_country .tt-dataset-search").text();
        $("#search_for_country .typeahead.tt-input").val(countryName);
        var country = countriesCode[countryName];
        var updatedOptions = {
            'areas': {}
        };
        updatedOptions.areas[country["CountryID"]] = {
            attrs: {
                fill: "#ed1c24"
            },
            attrsHover: {
                fill: "#ed1c24"
            }
        };
        if (oldID) {
            updatedOptions.areas[oldID] = {
                attrs: {
                    fill: "#fff"
                },
                attrsHover: {
                    fill: "#ccc"
                }
            };
        }
        oldID = country["CountryID"];
        $("#shahry_international_world_page").trigger('update', [updatedOptions, {}, {}, {
            animDuration: 1000
        }]);

        var geocoder = new google.maps.Geocoder();
        geocoder.geocode({
            'address': countryName
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {

                $("#shahry_international_world_page").trigger('zoom', {
                    level: 50,
                    latitude: results[0].geometry.location.lat(),
                    longitude: results[0].geometry.location.lng(),
                    animDuration: 200
                });
            } else {
                $("#shahry_international_world_page").trigger('zoom', {
                    level: 0
                });
            }
        });

        updateContent(oldID);

    });


    function updateContent(oldID) {
        $("#selected_country_details_area").hide();
        $("#get_the_key_btn").hide();
        var country = countriesByCode[oldID];
        $("#selected_country_details_area .countryName").html(
            country["Country"] + " (" + country["CountryCode"] + ")");
        $("#selected_country_details_area .international_calling_rate_value")
            .html(country["rate"] + ' ر.ق/للدقيقة ');
        var html = "";
        if (country["applicable"] != 0) {

            var ooo = "";
            if (country["Country"] == 'Nepal') {
                ooo = " <span style='padding-right: 5px;'>Nepal Telecom</span>";
            }


            $("#get_the_key_btn").show();


            html += '<div class="row-fluid no-margin availabity_status">\
                <div class="col-xs-12 no-padding ">\
					<span class="glyphicon glyphicon-ok" style=" color: #76C590;"></span> متاح\
                </div>\
                <s class="col-xs-12 no-padding text-muted">\
					<small>' + country["rate"] + ' ر.ق/للدقيقة</small>\
                </s>\
                <div class="col-xs-12 no-padding strike">\
					<small>' + country["applicable"] + ' ر.ق/للدقيقة</small>' + ooo + '\
                </div>\
            </div>';

            /** edit for nepal adding others **/
            if (country["Country"] == 'Nepal') {
                html += '<small> 0.45  ر.ق/للدقيقة</small> <span style="padding-right: 5px;">Others</span> ';
            }

        } else {
            html += '<div class="row-fluid no-margin availabity_status">\
                <div class="col-xs-12 no-padding ">\
					<span class="glyphicon glyphicon-remove" style=" color: #ed1c24;"></span> غير متاح\
                </div>\
            </div>';
        }


        $('[class*="-key"]').hide();
        switch(country["Country"]){
            case 'India':
                $('.india-key').show();
                break;
            case 'Pakistan':
                $('.pakistan-key').show();
                break;
            case 'Bangladesh':
                $('.bangladesh-key').show();
                break;
            case 'Sri Lanka':
                $('.sriLanka-key').show();
                break;
            case 'Nepal':
                $('.nepal-key').show();
                break;
            case 'Egypt':
                $('.egypt-key').show();
                break;
            case 'Philippines':
                $('.philippines-key').show();
                break;
        }


        $("#selected_country_details_area .shahry_server_key_availabilty .availabity_status")
            .html(html);
        $("#selected_country_details_area").fadeIn();
    }

});
