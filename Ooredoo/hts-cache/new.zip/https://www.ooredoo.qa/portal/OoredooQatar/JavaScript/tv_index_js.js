$(function() {

	$("a.btn[data-target='#watch-trailer-modal']").bind("click", function() {
		// alert($(this).attr("data-movie-url"));
		$('#trailer_frame').removeAttr('src');
		$('#trailer_frame').attr('src', $(this).attr("data-movie-url"));

	});

	$(".thumbnail").mouseover(function() {
		if ($(this).find(".auto_hide_caption").length != 0) {
			$(this).find(".auto_hide_caption").stop(true, true).animate({
				top : "0"
			}, 600, function() {
			});
		}
		return false;
	});
	$(".thumbnail").mouseleave(function() {
		if ($(this).find(".auto_hide_caption").length != 0) {
			$(this).find(".auto_hide_caption").stop(true, true).animate({
				top : "100%"
			}, 600, function() {
			});
		}
		return false;
	});
});