// Helper functions
function include(arr, obj) {
    return (arr.indexOf(obj) != -1);
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

var countries,
    services,
    operators,
    selected = {
        roamingOperators: [],
        passport: [],
        nonPassport: []
    },
    url = location.hostname === 'localhost' ? '//localhost:3001/api/roaming' : '/webgate/api',
    // localhost:3001/api/roaming
    // http://sit.ooredoo.qa/webgate/api
    lang = getCookie('CUSTOMER_CUSTOM_LOCAL') === 'en_GB' ? 'ENGLISH' : 'ARABIC';


// Roaming -> Call service
$(document).ready(function () {

    // Get Data
    $.ajax({
        url: url,
        type: "POST",
        dataType: "JSON",
        data: JSON.stringify({
            operation: "OoredooRoamingCountries",
            language: lang
        }),
        success: function (data) {
            countries = data.countries;
            services = data.services;
            populate(); // populate data

            // Stop loading
            $('._ooredoo_roaming_box_').removeClass('_ooredoo_loading_');

        },
        error: serviceError,
        timeout: serviceError
    });
});


// Roaming -> Populate Services / Countries list
function populate() {
    // Fill Service List
    $.each(services, function (idx, srv) {
        var nameFiltered = (srv.name).split(' ')[0];
        switch (nameFiltered.toLowerCase()) {
            case 'hala':
                nameFiltered += ' Prepaid';
                break;
            case 'shahry':
                nameFiltered += ' Postpaid';
                break;
        }
        $('#services ul').append('<li data-service="' + nameFiltered + '"  data-srvid="' + srv.id + '" >' + nameFiltered + '</li>');
    });

}

// Roaming -> Populate Countries
function fillCountries(srvId) {
    // Clear Dropdown Data
    $('#countries ul').html('');
    $('#countries .placeholder').text($('#countries').data('placeholder'));
    $('#states ul').html('');
    $('#states .placeholder').text($('#states .placeholder').data('origin'));
    $('.statesOptions').hide(); // Hide states dropdown


    $.each(countries, function (idx, con) {
        if (con.countryOperators) {
            $.each(con.countryOperators, function (idxx, op) {
                if (op.serviceId == srvId) {
                    $('#countries ul').append('<li data-code="' + con.isoCode + '">' + con.country + '</li>');
                    return false;
                }
            });
        }
    });

    bsDropDownFilter('#countries ul');
}

// Roaming -> Fill Services & Operators as per available services
function fillOperators(operators) {
    // Clear Dropdown Data
    $('#operators ul').html('');
    $('#operators .placeholder').text($('#operators .placeholder').data('origin'));


    // Store Operators as per selected service
    selected.operators = [];
    $.each(operators, function (idx, op) {
        // Get matched existed servicesID only
        if (selected.service.id == op.serviceId) {
            selected.operators.push(op);
            // Fill operators list -> Hidden in HTML
            // $('#operators ul').append('<li data-telecom="' + op.telecom + '"  data-srvID="' + op.serviceId + '" >' + op.telecom + '</li>');
        }
    });


    // clear selected passport
    selected.passport = [];
    selected.nonPassport = [];
    selected.roamingOperators = [];

    // Filter passport/non-passport operators
    $.each(selected.operators, function (idx, operator) {

        selected.roamingOperators.push(operator.telecom);

        if (operator.passportSupport === true)
            selected.passport.push(operator.telecom);
        if (operator.passportSupport === false)
            selected.nonPassport.push(operator.telecom);

    });

    showData();

}


// Roaming -> Dropdowns -> Bind events and fill operators
$('#countries').on('click', 'li', function () {
    var isoCode = $(this).data('code');

    // Select country
    $.each(countries, function (idx, country) {
        if (country.isoCode === isoCode) {

            // $('#_roaming_search_btn_').attr('disabled', 'disabled'); // disable search button

            // Clear Dropdown Data
            $('#states ul').html('');
            $('.statesOptions').hide(); // Hide states dropdown


            // operators = country.countryOperators;  // Fill operators, Not bound yet

            // clear selected data
            selected.roamingOperators = [];
            selected.passport = [];
            selected.nonPassport = [];
            selected.state = '';

            // Check operators first || Fail noData
            if (country.countryOperators) {
                // Set Dropdown default values
                $('#operators .placeholder').text($('#operators .placeholder').data('origin'));
                $('#states .placeholder').text($('#states .placeholder').data('origin'));

                // Set country
                selected.country = country;

                if (!country.states)
                    fillOperators(country.countryOperators); // Fill operators
                else {
                    $('._ooredoo_roaming_result_').slideUp('fast');

                    // List states first if found
                    $('.statesOptions').show(); // Show states dropdown

                    // Fill States List
                    $.each(country.states, function (idx, state) {
                        $('#states ul').append('<li data-iso="' + state.countryIsoCode + '" data-stateid="' + state.id + '" data-state="' + state.name + '" >' + state.name + '</li>');
                    });
                    bsDropDownFilter('#states ul');

                    // Clear Dropdown Data
                    $('#operators ul').html('');
                }

            } else {
                // Set Dropdown noData values
                $('#operators .placeholder').text($('#operators .placeholder').data('noservice')); // No Operator text
                $('#operators ul').html('');
            }

            return false;
        }

    });


});

// Roaming -> Select State
$('#states').on('click', 'li', function () {
    $this = $(this);

    function fillData() { // Fill data
        var stateOperators = [],
            generalOperators = []; // assumed for capital state (hasNoOperators)

        // Set selected State
        selected.state = {
            id: $this.data('stateid'),
            name: $this.data('state')
        };

        $.each(selected.country.countryOperators, function (idx, operator) {
            if (operator.stateId) {
                if (parseInt(operator.stateId) === selected.state.id) {
                    stateOperators.push(operator);
                }
            } else {
                generalOperators.push(operator);
            }
        });

        if (stateOperators.length !== 0)
            fillOperators(stateOperators); // Fill operators
        else
            fillOperators(generalOperators); // Fill operators

    }

    if (selected.state) {
        if (selected.state.name !== $(this).data('state')) { // Close Panel if new
            fillData()
        }
    } else {
        fillData()
    }

});

// Roaming -> Select Service ID
$('#services').on('click', 'li', function () {

    if (selected.service) {
        if (selected.service.id !== $(this).data('srvid')) { // Close Panel if new

            selected.service = {
                id: $(this).data('srvid'),
                name: $(this).data('service')
            };
            fillCountries(selected.service.id);

            $('._ooredoo_roaming_result_').slideUp('fast');
        }
    } else {
        selected.service = {
            id: $(this).data('srvid'),
            name: $(this).data('service')
        };
        fillCountries(selected.service.id);
    }
});


// Roaming -> Select operator
$('#operators').on('click', 'li', function () {
    var telecom = $(this).data('telecom');

    // Show selected Operator Data
    $('#_roaming_search_btn_').removeAttr('disabled'); // Enabled button
    $.each(selected.operators, function (idx, operator) {
        if (operator.telecom === telecom) {
            // Set operator
            selected.op = operator;
        }
    });

    showData();

});

function showData() {
    bindHTML();
    // Show result panel
    $('._ooredoo_roaming_result_').slideDown('fast');
}

function bindHTML() {
    // Title
    if (selected.country.flag)
        $('#_country_flag').attr('src', 'data:image/png;base64,' + selected.country.flag).show();
    else
        $('#_country_flag').hide();

    if (selected.state)
        $('#_state_name').text('- ' + selected.state.name + ' ');
    else
        $('#_state_name').text('');


    $('#_country_name').text(selected.country.country);
    $('#_operator_name').text('(' + selected.service.name + ')');


    // Rates
    // Ooredoo pasport rates
    if(selected.country.opRates){
        $('#_op_rate_callSame').text(selected.country.opRates.callingSameCountryRate);
        $('#_op_rate_callAnother').text(selected.country.opRates.callingAnotherCountryRate);
        $('#_op_rate_smsRate').text(selected.country.opRates.smsRate);
        $('#_op_rate_callQatar').text(selected.country.opRates.callingQatarRate);
        $('#_op_rate_receivingCalls').text(selected.country.opRates.receivingCallRate);
        $('#_op_rate_internetRate').text(selected.country.opRates.internetRate);
    }


    // Standard rates
    if(selected.country.standardRates){
        $('#_rate_callSame').text(selected.country.standardRates.callingSameCountryRate);
        $('#_rate_callAnother').text(selected.country.standardRates.callingAnotherCountryRate);
        $('#_rate_smsRate').text(selected.country.standardRates.smsRate);
        $('#_rate_callQatar').text(selected.country.standardRates.callingQatarRate);
        $('#_rate_receivingCalls').text(selected.country.standardRates.receivingCallRate);
        $('#_rate_internetRate').text(selected.country.standardRates.internetRate);
    }


    // Non passport
    if (selected.nonPassport.length > 0) {
        $('#nonPassportOp').html('').removeClass('notAvailable');
        $('.standardRates').show();
        $.each(selected.nonPassport, function (idx, telcom) {
            $('#nonPassportOp')
                .append('<span>' + telcom + '</span>')
        })
    } else {
        $('#nonPassportOp')
            .addClass('notAvailable')
            .html('<i class="fa fa-exclamation-circle"></i> <small>' + $('#nonPassportOp').data('empty-text') + '</small>');
        $('.standardRates').hide();
    }

    // Passport
    if (selected.passport.length > 0) {
        $('#passportOp').html('').removeClass('notAvailable');
        $('.opRates').show();
        $.each(selected.passport, function (idx, telcom) {
            $('#passportOp')
                .append('<span>' + telcom + '</span>')
        });
    } else {
        $('#passportOp')
            .addClass('notAvailable')
            .html('<i class="fa fa-exclamation-circle"></i> <small>' + $('#passportOp').data('empty-text') + '</small>');
        $('.opRates').hide();
    }
}

// Error in service
function serviceError() {
    $('._ooredoo_roaming_box_').removeClass('_ooredoo_loading_');
    $('._ooredoo_service_error_').show();
}

// Close Roaming panel
$('.closePanel').click(function (e) {
    e.preventDefault();
    $(this).parent().slideUp('fast');
});

// Update dropdown options - // Recommended to be global
$('.dropdown_select').each(function () {
    var that = $(this);
    that.on('click', 'li', function () {
        that.find('.placeholder').text($(this).text());
    })
});