$(function() {
	$(".thumbnail").mouseover(function() {
		if ($(this).find(".auto_hide_caption").length != 0) {
			$(this).find(".auto_hide_caption").stop(true, true).animate({
				top : "0"
			}, 600, function() {
			});
		}
		return false;
	});
	$(".thumbnail").mouseleave(function() {
		if ($(this).find(".auto_hide_caption").length != 0) {
			$(this).find(".auto_hide_caption").stop(true, true).animate({
				top : "100%"
			}, 600, function() {
			});
		}
		return false;
	});
});