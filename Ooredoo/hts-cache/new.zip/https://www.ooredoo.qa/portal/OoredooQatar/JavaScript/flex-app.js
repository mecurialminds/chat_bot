﻿$(function () {
    callLastValue = 0;
    DataLastValue = 0;
    internationalLastValue = 0;

    var rtl = $('.flex-rtl');
    var app = new Vue({
        el: '#flex-app',
        data: {
            ratePlaceHolderOnLeave: false,
            topUpExistMobile: 'true',
            tryToEditInternational: false,
            sliderRange: 40,
            countryCalculate: {
                country:"",
                flex20:"",
                flex60:"",
                flex100:"",
                flex150:"",
                flex200:"",
                flexPoints:""
            },
            countryCheck: {
                country: "",
                flex20:"",
                flex60: "",
                flex100: "",
                flex150: "",
                flex200: "",
                flexPoints: ""
            },
            flex: 1000,
            rate: {
                international:0,
                call: 1,
                data: 0.13,
            },
            usedFlex: {
                international:0,
                call:0,
                data:0,
            },
            usedNumber: {
                international:0,
                call: 0,
                data: 0
            },
            countries: countriesRate,
           
        },
        mounted: function () {
            setTimeout(function () {
                app.init();
            })
            

        },
        created: function () {
        },
        methods: {
            updateSliderRange: function (slider,max) {
                slider.noUiSlider.updateOptions({
                    start: [0],
                    step: 1,
                    connect: [true, false],
                    range: {
                        'min': 0,
                        'max': max
                    }
                });
            },
            toggleSteps: function (step) {
                if (step == 'slider') {
                    $(".proceed-top-up-container").fadeOut("fast", function () {
                        $(".flex-calculation-bordered").fadeIn();
                    });
                }
                else if (step == 'top up') {
                    $(".flex-calculation-bordered").fadeOut("fast", function () {
                        $(".proceed-top-up-container ").fadeIn();
                    });
                }
            },
            selectSearchCountry: function (countryName) {
                var index = _.findIndex(this.countries, function (o) { return o.country == countryName; });
                this.countryCheck = this.countries[index];
             

            },
            selectSliderCountry: function (countryName) {
                var index = _.findIndex(this.countries, function (o) { return o.country == countryName; });
                this.countryCalculate = this.countries[index];
                this.rate.international = this.countryCalculate.flexPoints;
                internationalLastValue = 0;
                this.usedFlex.international = 0;
                this.usedNumber.international = 0;
                internationalSlider.noUiSlider.set(0);
                
                $("#internation-slider .custom-tool-tip").remove()
            },
            createSlider: function (slider,min,max,step) {
                return noUiSlider.create(slider, {
                    start: [0],
                    step: step,
                    direction: rtl.length > 0 ? 'rtl' :'ltr' ,
                    connect: [true, false],
                    range: {
                        'min': min,
                        'max': max
                    },
                });
            },
            init: function () {
                internationalSlider = document.getElementById('internation-slider');
                callSlider = document.getElementById('local-call-slider');
                dataSlider = document.getElementById('local-data-slider');
               
                this.createSlider(internationalSlider, 0, this.sliderRange, 1);
                this.createSlider(callSlider, 0, this.sliderRange, 1);
                this.createSlider(dataSlider, 0, this.sliderRange, 1);

                //on call slider change event
                callSlider.noUiSlider.on('slide', function (values) {

                    toBemulti = (app.flex / app.rate.call) / app.sliderRange; // felx * call rate / 20 slider range
                    rangeValue = parseFloat(values[0]);
                    var callsNumber = toBemulti * rangeValue;
                    x = app.usedFlex.data + app.usedFlex.international
                    y = callsNumber * app.rate.call + x;
                    if ((callsNumber * app.rate.call) + (app.usedFlex.data + app.usedFlex.international) > app.flex + 0.1) {
                        callSlider.noUiSlider.set(callLastValue);
                    } else {

                        callLastValue = parseInt(values[0]);
                     
                        app.usedNumber.call = callsNumber
                        callFlexUsed = callsNumber * app.rate.call;
                        $('#call .noUi-tooltip').text(app.usedNumber.call)
                        app.usedFlex.call = callFlexUsed;
                        var callPlaceHolder = rtl.length > 0 ? ' الرسائل النصية و الدقائق المحلية ' + '<span>' + Math.round(app.usedFlex.call) + '</span>' : Math.round(app.usedFlex.call) + " Local Calls & SMS";
                        $('#local-call-slider .noUi-handle').html('<p class="custom-tool-tip">' + callPlaceHolder + ' </p>')
                 

                    }
                });
                internationalSlider.noUiSlider.on('slide', function (values) {
                    if (app.rate.international > 0) {
                        toBemulti = (app.flex / app.rate.international) / app.sliderRange; // felx * call rate /  slider range
                    }
                    rangeValue = parseFloat(values[0]);
                    var interntionalNumber = toBemulti * rangeValue;
                    
                    if ((interntionalNumber * app.rate.international) + (app.usedFlex.data + app.usedFlex.call) > app.flex + 0.1) {
                       
                        internationalSlider.noUiSlider.set(internationalLastValue);
                    } else {

                        internationalLastValue = parseInt(values[0]);
                        //$('#callPlaceholder').text(callsNumber);
                        app.usedNumber.international = interntionalNumber
                        internationalFlexUsed = interntionalNumber * app.rate.international;
                        //$('#call .noUi-tooltip').text(app.usedNumber.international)
                        //$('#call-flex-used').text(callFlexUsed);
                        app.usedFlex.international = internationalFlexUsed
                        var interPlaceHolder = rtl.length > 0 ? 'دقائق المكالمات الدولية ' + '<span>' + Math.round(app.usedFlex.international) + '</span>' : Math.round(app.usedFlex.international) + " International";
                        setTimeout(function () { 
                            $('#internation-slider .noUi-handle').html('<p class="custom-tool-tip">' + interPlaceHolder + '</p>')
                        })
                      


                    }
                });
                dataSlider.noUiSlider.on('slide', function (values) {
                    toBemulti = (app.flex / app.rate.data) / app.sliderRange; // felx / data rate /  slider range
                    rangeValue = parseInt(values[0]);
                    var dataNumbers = toBemulti * rangeValue;

                    //$('#local-data-slider .noUi-handle').html('<p class="custom-tool-tip">' + Math.round(323) + ' Local Data</p>')
                    dataTempUse = (dataNumbers * app.rate.data)
                    if (dataTempUse + (app.usedFlex.call + app.usedFlex.international) > app.flex + 0.1) {
                        var remainingPoints = app.sliderRange - (internationalLastValue + DataLastValue + callLastValue)
                        dataSlider.noUiSlider.set(DataLastValue);
                    } else {
                        DataLastValue = parseInt(values[0]);
                        app.usedNumber.data = dataNumbers
                        dataFlexUsed = dataNumbers * app.rate.data
                        app.usedFlex.data = dataFlexUsed
                        var dataPlaceHolder = rtl.length > 0 ? 'بيانات المحلية   ' + '<span>' + Math.round(app.usedFlex.data) + '</span>' : Math.round(app.usedFlex.data) + " Local data";
                       $('#local-data-slider .noUi-handle').html('<p class="custom-tool-tip">'  + dataPlaceHolder + '</p>')

                    }
                });


            },
            selectFlexCard: function (flex) {
                this.flex = flex;
                $(".custom-tool-tip").remove();
                if($(window).width() < 750) {
                $("html, body").delay(0).animate({
                    scrollTop: $('.calculation-inner-container aside').offset().top-30
                }, 300);
                }
                    
               
                //reset slider value
                if (flex == 500) {
                    this.sliderRange = 20
                    this.updateSliderRange(dataSlider, 20);
                    this.updateSliderRange(internationalSlider, 20);
                    this.updateSliderRange(callSlider, 20);
                }
                if (flex == 1000) {
                    this.sliderRange = 40
                    this.updateSliderRange(dataSlider, 40);
                    this.updateSliderRange(internationalSlider, 40);
                    this.updateSliderRange(callSlider, 40);
                }
                if (flex == 1700) {
                    this.sliderRange = 68
                    this.updateSliderRange(dataSlider, 68);
                    this.updateSliderRange(internationalSlider, 68);
                    this.updateSliderRange(callSlider, 68);
                }
                if (flex == 2500) {
                    this.sliderRange = 100
                    this.updateSliderRange(dataSlider, 100);
                    this.updateSliderRange(internationalSlider, 100);
                    this.updateSliderRange(callSlider, 100);
                }
              
                 this.reset()
            },
            reset: function () {

                internationalLastValue = 0;
                this.usedFlex.international = 0;
                this.usedNumber.international = 0;
                internationalSlider.noUiSlider.set(0);

                callLastValue = 0;
                this.usedFlex.call = 0;
                this.usedNumber.call = 0;
                callSlider.noUiSlider.set(0);

                DataLastValue = 0;
                this.usedFlex.data = 0;
                this.usedNumber.data = 0;
                dataSlider.noUiSlider.set(0);
            }
            ,
            openSearchModal: function () {
                $("#searchModal").modal()
            }
        }
    });
  
    $(document).ready(function () {
        //active collaps header 
        $('.panel-heading a').click(function () {
            $('.panel-heading').removeClass('actives');
            $(this).parents('.panel-heading').addClass('actives');

            $('.panel-title').removeClass('actives'); //just to make a visual sense
            $(this).parent().addClass('actives'); //just to make a visual sense

          
        });
        //check search
        $("select#country-search").select2({
            placeholder: rtl.length > 0 ? 'اختر البلد ' : "Select your country",
            theme: "bootstrap",


        });
     
        $('select#country-search')
       .on("change", function (e) {
           app.selectSearchCountry($("select#country-search").val());
           $('#searchModal').modal('toggle');
       })

        $('select#country-slider')
       .on("change", function (e) {
           app.selectSliderCountry($("#country-slider").val());
       })

    });


    //underline the select2 match key word
    var query = {}; 
    var $element = $('select#country-slider');

    function markMatch(text, term) {
        // Find where the match is
        var match = text.toUpperCase().indexOf(term.toUpperCase());

        var $result = $('<span></span>');

        // If there is no match, move on
        if (match < 0) {
            return $result.text(text);
        }

        // Put in whatever text is before the match
        $result.text(text.substring(0, match));

        // Mark the match
        var $match = $('<span class="select2-rendered__match"></span>');
        $match.text(text.substring(match, match + term.length));

        // Append the matching text
        $result.append($match);

        // Put in whatever is after the match
        $result.append(text.substring(match + term.length));

        return $result;
    }

    $element.select2({
        templateResult: function (item) {
            // No need to template the searching text
            if (item.loading) {
                return item.text;
            }

            var term = query.term || '';
            var $result = markMatch(item.text, term);

            return $result;
        },
        placeholder: rtl.length > 0 ? ' اختر بلدك لتحريك شريط التمرير ' : "Select your country to move slider",
        theme: "bootstrap",
        language: {
            searching: function (params) {
                // Intercept the query as it is happening
                query = params;

                // Change this to be appropriate for your application
                return 'Searching…';
            }
        }
    });


})