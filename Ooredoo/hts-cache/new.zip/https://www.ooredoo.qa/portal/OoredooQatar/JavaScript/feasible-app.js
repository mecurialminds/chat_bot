var url = "/webgate/api";
function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
function expireCallBack() {
  $('#submitBtnQue').prop("disabled", true);

}
function recaptchaCallback() {
  $('#submitBtnQue').prop("disabled", false);
}

$('#submitResult').on('hidden', function () {
  app.user ={
    name:"",
    contactNumber:"",
    qid:"",
  };
  app.customerNumber = ""
})
Vue.use(VueI18n);
Vue.use(VeeValidate);
// ready translated locales
var  messages = {
  en: {
    "CHECK_FIBER_FEASIBILITY_AT_YOUR_PLACE":"Check Fibre Feasibility at your place",
    "INPUT_PLACE_HOLDER":"Your Electricity Number",
    "ELECTRICITY_NUMBER":"Electricity number",
    "OOREDOO_NUMBER":"Ooredoo Number",
    "PLEASE_FILL_THE_BELOW_FORM_TO_GET_OUR_FIBRE_CONNECTION":"Please fill the below form to apply for a Fibre Connection",
    "CHECK_AVAILABILITY":"CHECK FEASIBILITY",
    "ENTER_YOUR_FULL_NAME":"Enter your Full name",
    "ENTER_YOUR_CONTACT_NUMBER":"Enter your contact number",
    "ENTER_YOUR_QID":"Enter your QID",
    "SUBMIT":"Submit",
    "ALL_FIELD_ARE_REQUIRED":"All fields are required",
    "OK":"OK",
    "REQUEST_CONFIRMATION":"Request Confirmation",
    "VALIDATION_NAME":"Please enter your Full Name",
    "VALIDATION_CONTACT_NUMBER":"Please enter a valid Contact Number",
    "VALIDATION_QID":"Please enter a valid Qatar ID",
    "ERROR":"Registered Already",
    "VALIDATION_ELECTRICITY_OOREDOO_NUMBER":"Please enter a valid Electricity number",



  },
  ar: {
    "CHECK_FIBER_FEASIBILITY_AT_YOUR_PLACE":"تعرف على إمكانية تركيب الألياف الضوئية في مكان إقامتك/عملك",
    "INPUT_PLACE_HOLDER":"رقم الكهرباء",
    "ELECTRICITY_NUMBER":"رقم الكهرباء",
    "OOREDOO_NUMBER":"رقم Ooredoo",
    "PLEASE_FILL_THE_BELOW_FORM_TO_GET_OUR_FIBRE_CONNECTION":"يرجى تعبئة النموذج أدناه لتحصل على خدمات اتصالات عبر الألياف الضوئية",
    "CHECK_AVAILABILITY":"تعرف على  إمكانية تركيب الألياف الضوئية ",
    "ENTER_YOUR_FULL_NAME":"أدخل اسمك الكامل ",
    "ENTER_YOUR_CONTACT_NUMBER":"أدخل رقماً للتواصل معك",
    "ENTER_YOUR_QID":"أدخل رقم البطاقة الشخصية القطرية",
    "SUBMIT":"أرسل",
    "ALL_FIELD_ARE_REQUIRED":"جميع الحقول مطلوبة",
    "OK":"موافق",
    "REQUEST_CONFIRMATION":" تأكيد ",
    "VALIDATION_NAME":"يرجى إدخال اسمك الكامل ",
    "VALIDATION_CONTACT_NUMBER":"يرجى إدخال رقماً صحيحاً",
    "VALIDATION_QID":" يرجى إدخال رقم البطاقة الشخصية القطرية صحيحاً",
    "ERROR":"مسجل بالفعل",
    "VALIDATION_ELECTRICITY_OOREDOO_NUMBER":"يرجي ادخال رقم الكهرباء  صحيحا",


  }
};
lang = getCookie('CUSTOMER_CUSTOM_LOCAL');
// Create VueI18n instance with options
var i18n = new VueI18n({
  locale:lang == 'ar_QA' ? "ar" : "en", // set locale
  messages // set locale messages
});
var serviceLang = lang == 'ar_QA' ? "ARABIC" : "ENGLISH";
var app = new Vue({
  i18n: i18n,
  el: '#feasability-app',
  data: {
    customerNumber:"",
    registerIsValid:"",
    type:"ELECTRICITY_NUMBER",
    isDisabled:true,
    available:"",
    isLoading:false,
    Isvalid:true,
    electricityIsValid:true,
    ooredooNumberIsValid:true,
    alertMsg:"",
    registerAlertMsg:"",
    actionDetails:"",
    user:{
      name:"",
      contactNumber:"",
      qid:"",
    }
  },
  methods:{
    resetForm: function () {

      this.user = {
        name:"",
        contactNumber:"",
        qid:"",
      };
        this.errors.clear();
      this.customerNumber = "";
      this.$validator.clean();

      $('.slideing-form').slideUp();
    },
    submitRegister: function functionName(user) {
      this.$validator.validateAll().then(function (result) {
          if (result) {
            app.isLoading = true;
            var type = app.type == "ELECTRICITY_NUMBER" ? app.type : "OOREDOO_NUMBER";
            var settings = {
                "async": true,
                "crossDomain": true,
                "url": url,
                "method": "POST",
                "headers": {
                    "content-type": "application/json",
                    "cache-control": "no-cache",

                },
                "processData": false,
                "data": JSON.stringify({
                          "operation": "FiberRegistrationForm",
                          "language": serviceLang,
                          "parameters": [
                            user.name, //Name
                            user.contactNumber, //Phone
                            user.qid, //QID
                            app.actionDetails, // actionDetails field from previous response.
                            type, //Search type SERVICE_NUMBER/ELECTRICITY_NUMBER
                            app.customerNumber //Search parameter
                          ]
                        })
            };
              $.ajax(settings).done(function (response) {
                var response = JSON.parse(response);
                app.isLoading = false;

                app.registerIsValid = response.result;
                app.registerAlertMsg = response.alertMessage;
                $('#submitResult').modal();
              });
          };
      })



    },
    getAvailable : function (number,type) {
      if(type == 'ELECTRICITY_NUMBER' && (number.length < 3 || number.length > 8)  ) {
        this.electricityIsValid = false ;
        this.ooredooNumberIsValid = true;
        return false;
      }
      if(type == 'SERVICE_NUMBER' && (number.length < 4 || number.length > 19)  ) {
        this.electricityIsValid = true ;
        this.ooredooNumberIsValid = false;
        return false;
      }
      this.electricityIsValid = true ;
      this.ooredooNumberIsValid = true;
      app.isLoading = true;
      var type = app.type == "ELECTRICITY_NUMBER" ? app.type : "OOREDOO_NUMBER";
      var settings = {
          "async": true,
          "crossDomain": true,
          "url": url,
          "method": "POST",
          "headers": {
              "content-type": "application/json",
              "cache-control": "no-cache",

          },
          "processData": false,
          "data": JSON.stringify({
                    "operation": "FiberFeasibility",
                    "language": serviceLang,
                    "parameters": [
                      type, //Search type SERVICE_NUMBER/ELECTRICITY_NUMBER
                      this.customerNumber //Search parameter
                    ]
                  })
      };
      $.ajax(settings).done(function (response) {
        var response = JSON.parse(response);
        app.isLoading = false;

        if(response.result) {
          app.alertMsg = response.niMessage;
          app.available = response.available;
          app.actionDetails = response.actionDetails;
          $('.slideing-form').slideDown();
        }
      });
    }

  }

});
